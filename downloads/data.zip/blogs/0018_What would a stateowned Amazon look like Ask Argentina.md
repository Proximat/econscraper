What would a state-owned Amazon look like? Ask Argentina | openDemocracy
Close
Help us uncover the truth about Covid-19
------------------------------------------
The Covid-19 public inquiry is a historic chance to find out what really happened.
[Make a donation]()
[Open Democracy Home Page](/en/)
Select language
* [l`rby@](/ar/)
* [English: Global](/en/?requested-lang=en)
* [English: UK](/en/uk/?requested-lang=en-gb)
* [Espanol](/es/)
* [Portugues](/pt/)
* [Russkii](/ru/)
Open menu
* Select language
+ [English: Global](/en/?requested-lang=en)
+ [English: UK](/en/uk/?requested-lang=en-gb)
+ [Espanol](/es/)
+ [Portugues](/pt/)
+ [Russkii](/ru/)
* All
Themes
--------
+ [Conflict & security](/en/tagged/conflict-security/)
+ [Crime, justice & law](/en/tagged/crime-justice-law/)
+ [Cultural politics](/en/tagged/cultural-politics/)
+ [Economics](/en/tagged/economics/)
+ [Environment](/en/tagged/environment/)
+ [Gender & sexuality](/en/tagged/gender-sexuality/)
+ [Health & care](/en/tagged/health-care/)
+ [Media & communications](/en/tagged/media-communications/)
+ [Migration](/en/tagged/migration/)
+ [Politics & activism](/en/tagged/politics-activism/)
+ [Racism & xenophobia](/en/tagged/racism-xenophobia/)
+ [Religion & spirituality](/en/tagged/religion-spirituality/)
Projects
----------
+ [50.50](/en/5050/)
+ [Beyond Trafficking and Slavery](/en/beyond-trafficking-and-slavery/)
+ [Dark Money Investigations](/en/dark-money-investigations/)
+ [democraciaAbierta](/en/democraciaabierta/)
+ [Freedom of Information](/en/freedom-of-information/)
+ [Live discussions](/en/live-discussions/)
+ [oDR](/en/odr/)
+ [ourEconomy](/en/oureconomy/)
+ [Podcasts](/en/podcasts/)
+ [Who Funds You?](/en/who-funds-you/)
Regions
---------
+ [Africa](/en/tagged/africa/)
+ [Central Asia](/en/tagged/central-asia/)
+ [China, East & SE Asia](/en/tagged/china-east-se-asia/)
+ [Europe](/en/tagged/europe/)
+ [India & South Asia](/en/tagged/india-south-asia/)
+ [Israel & Palestine](/en/tagged/israel-palestine/)
+ [Latin America](/en/tagged/latin-america/)
+ [Middle East & North Africa](/en/tagged/middle-east-north-africa/)
+ [Oceania](/en/tagged/oceania/)
+ [Russia](/en/tagged/russia/)
+ [Turkey](/en/tagged/turkey/)
+ [Ukraine](/en/tagged/ukraine/)
+ [United Kingdom](/en/tagged/united-kingdom/)
+ [United States & Canada](/en/tagged/united-states-canada/)
About
-------
Authors
---------
+ [Submit](/en/submission-form/)
Follow openDemocracy
----------------------
+ [openDemocracy Facebook]()
+ [openDemocracy Twitter]()
+ [openDemocracy Instagram]()
+ [openDemocracy Youtube]()
+ [openDemocracy Newsletter](#newsletter)
* Themes
+ [Conflict & security](/en/tagged/conflict-security/)
+ [Crime, justice & law](/en/tagged/crime-justice-law/)
+ [Cultural politics](/en/tagged/cultural-politics/)
+ [Economics](/en/tagged/economics/)
+ [Environment](/en/tagged/environment/)
+ [Gender & sexuality](/en/tagged/gender-sexuality/)
+ [Health & care](/en/tagged/health-care/)
+ [Media & communications](/en/tagged/media-communications/)
+ [Migration](/en/tagged/migration/)
+ [Politics & activism](/en/tagged/politics-activism/)
+ [Racism & xenophobia](/en/tagged/racism-xenophobia/)
+ [Religion & spirituality](/en/tagged/religion-spirituality/)
* Projects
+ [50.50](/en/5050/)
+ [Beyond Trafficking and Slavery](/en/beyond-trafficking-and-slavery/)
+ [Dark Money Investigations](/en/dark-money-investigations/)
+ [democraciaAbierta](/en/democraciaabierta/)
+ [Freedom of Information](/en/freedom-of-information/)
+ [Live discussions](/en/live-discussions/)
+ [oDR](/en/odr/)
+ [ourEconomy](/en/oureconomy/)
+ [Podcasts](/en/podcasts/)
+ [Who Funds You?](/en/who-funds-you/)
* Regions
+ [Africa](/en/tagged/africa/)
+ [Central Asia](/en/tagged/central-asia/)
+ [China, East & SE Asia](/en/tagged/china-east-se-asia/)
+ [Europe](/en/tagged/europe/)
+ [India & South Asia](/en/tagged/india-south-asia/)
+ [Israel & Palestine](/en/tagged/israel-palestine/)
+ [Latin America](/en/tagged/latin-america/)
+ [Middle East & North Africa](/en/tagged/middle-east-north-africa/)
+ [Oceania](/en/tagged/oceania/)
+ [Russia](/en/tagged/russia/)
+ [Turkey](/en/tagged/turkey/)
+ [Ukraine](/en/tagged/ukraine/)
+ [United Kingdom](/en/tagged/united-kingdom/)
+ [United States & Canada](/en/tagged/united-states-canada/)
* [About](/en/about/)
* Search
Search
* [Donate]()
[Donate]()
Close
Close
Please type and press enter
Submit
[ourEconomy: Opinion](/en/oureconomy/)
What would a state-owned Amazon look like? Ask Argentina
==========================================================
Correo Compras promises to benefit workers, consumers and sellers, and could even use big data for the public good.
* [Espanol](/es/correo-compras-amazon-estatal-argentina/)
* [Portugues](/pt/amazon-estatal-correo-compras-argentina/)
[Cecilia Rikap](/es/author/cecilia-rikap/)
24 November 2020, 2.36pm
![]()
Image: Fibonacci Blue, cc by 2.0
Share this
============
* [Share on Twitter]( would a state-owned Amazon look like? Ask Argentina&url=https%3A//www.opendemocracy.net/en/oureconomy/what-would-state-owned-amazon-look-ask-argentina/?utm_source=tw&utm_medium=ar)
* [Share on Facebook]()
* [Share on WhatsApp]()
* [Share via email](/cdn-cgi/l/email-protection#8bb4adf8fee9e1eee8ffb6dce3eaffaeb9bbfce4fee7efaeb9bbeaaeb9bbf8ffeaffeea6e4fce5eeefaeb9bbcae6eaf1e4e5aeb9bbe7e4e4e0aeb9bbe7e2e0eeaeb8cdaeb9bbcaf8e0aeb9bbcaf9eceee5ffe2e5eaade9e4eff2b6e3fffffbf8aeb8caa4a4fcfcfca5e4fbeee5efeee6e4e8f9eae8f2a5e5eeffa4eee5a4e4fef9eee8e4e5e4e6f2a4fce3eaffa6fce4fee7efa6f8ffeaffeea6e4fce5eeefa6eae6eaf1e4e5a6e7e4e4e0a6eaf8e0a6eaf9eceee5ffe2e5eaa4b4feffe6d4f8e4fef9e8eeb6eee6adfeffe6d4e6eeefe2fee6b6eaf9)
* [Share link](#)
URL copied to clipboard
In October, a historic US Congressional investigation into big tech published a report which proposed a raft of new regulations to rein in the power of tech giants like Amazon. But what if instead of relying on regulations, the US introduced a new online marketplace that delivered low prices to consumers, lower costs for merchants and living wages for workers in e-commerce?
Last October, Argentina announced the creation of an online marketplace called
["Correo Compras"]()
. The platform is to be run by a state-owned company,
[Correo Argentino]()
, which is also the country's official postal service.
Argentina has been severely hit by the Covid-19 pandemic, and its lockdown has been among the longest. Even before the pandemic internet penetration in Argentina was already high (
[74%]()
), and since the lockdown e-commerce and other digital services thrived in the country. Through its publicly owned option, the government aims to offer an alternative to Latin America's current e-commerce private octopus.
Latin America's Amazon
------------------------
Though you may never have heard of it, the Amazon of the Amazonian continent is not Amazon.com - the global behemoth whose market capitalization grew 75% this year. Rather, Latin America's amazonian e-commerce honors go to
[MercadoLibre]()
, or 'FreeMarket' in English. Born in 1999, the company quickly adopted the business models first of eBay and then of Amazon and China's Alibaba.
###
[Help us uncover the truth about Covid-19]()
The Covid-19 public inquiry is a historic chance to find out what really happened.
[Make a donation]()
The absence of foreign platforms in the region allowed MercadoLibre to develop a profitable business. The company now has the largest e-commerce platform in Latin America, operating in eighteen countries, with 51.5 million active users.
Far from the image of a 'national champion' that contributes to other businesses' catching-up and, eventually, the region's development, MercadoLibre simply copied
[Amazon]()
's business model. It is an e-commerce marketplace that squeezes value from third-party sellers.
Just like Bezos's giant, MercadoLibre imposes transaction conditions: from fees to be listed higher when people search for goods, to advertising campaigns inside the marketplace. MercadoLibre also forces sellers to offer
[free shipping]()
when the purchase is above USD25.
Once again copying
[Amazon]()
, MercadoLibre's delivery network mobilizes an Uber-like army of drivers seeking out a living through the sharing economy, and its fulfillment centers are beset by low pay and stressful working conditions. Though MercadoLibre technically is a union shop, it has implemented a new
[flexible employment contract]()
that basically optimizes profits and minimizes pay.
In comparison, the government's "Correo Compras" will not outsource shipping (which is in fact its core business) and promises to create quality jobs with a living wage for its employees.
The need to regulate tech giants has become all the more urgent with the pandemic. As well as the recent
[US Congress investigation report]()
, this was also made clear by the recent Justice Department
[lawsuit against Google]()
, which may be followed by similar actions against the other US tech giants.
According to
[UNCTAD]()
, before the pandemic Amazon concentrated over a third of the world's online retail activity. In Argentina, MercadoLibre concentrates around half of that market and has been the clear winner of the pandemic. While the
[IMF forecasts]()
the global economy to shrink by 4.4% and (and 8.1% in Latin America's - the worst among the world's major regions), MercadoLibre celebrated a
[45%]()
increase in gross profits for the first half of 2020.
Argentina, between tech unicorns and a long-term economic crisis
------------------------------------------------------------------
Argentina is a worldwide supplier of
[cheap agrarian and mining commodities]()
, leading to economic, ecological, and
[health]()
consequences.
Before the pandemic, while MercadoLibre was thriving Argentina was already in a severe economic crisis partly triggered by a trade deficit due to low commodity prices. Coupled with more than a decade of inflation, wages kept losing their purchasing power despite increasing in nominal terms. In addition, an international debt spiral led to the IMF's largest ever loan in 2018, which was not used to recover the economy but to pay previous debt which ultimately ended up financing capital flight.
Regardless of this long-standing crisis and its
[structural underdevelopment]()
, Argentina hosts its own tech giants. In addition to MercadoLibre, the software development company
[Globant]()
and travel platform
[Despegar]()
were all unicorns before their US listings. They are leading companies in Latin America, and Globant also operates in the US and Europe. Other tech companies that have gained the unicorn label in the country include OLX and Auth0.
They were all aided by a
[software promotion regime]()
created in 2004 and by the country's cheap skilled workforce. According to the
[World Bank]()
, Argentina has a 90% gross enrollment ratio in tertiary education. The same figure is 88% for the United States, however the average IT salary in the US is around USD 200,000 while in Argentina it is less than USD 10,000.
The public digital economy
----------------------------
It is in this context that the new Argentinean administration launched Correo Compras, offering over 2,000 products. It is a
*high-risk, high-gain*
initiative with the potential to tilt the scale in favour of consumers and small and medium enterprises that cannot cope with the costs of offering in MercadoLibre's private marketplace.
Public platforms are not an entirely new phenomenon. In Indonesia, a state-owned enterprise already manages the digital payment service
[LinkAja]()
. Brazil has seen the emergence of several public platforms since the pandemic, like the delivery platform
[FiqueNoLar]()
that operates in the northern part of the country, where the most popular private delivery apps did not have a service.
Moreover, in the midst of the Covid-19 pandemic some advocated that the US government should
[nationalize Amazon]()
and
[use its logistics network]()
to assure the delivery of essential goods to all US citizens.
In Argentina, Correo Compras promises to have the lowest prices by being cheaper for sellers, who will only have to pay a platform maintenance fee. This public e-commerce platform is part of the Argentinean government's broader attempt to regulate the digital economy and offer public alternatives to existing private businesses.
Argentina's national bank,
[Banco Nacion]()
, has launched BNA+ - an e-wallet to compete with MercadoLibre's e-payment business,
[MercadoPagos]()
. MercadoPagos was also favored by the lockdown - its total payment transactions jumped 122.9% year on year, totaling 404.8 million transactions in the second quarter of 2020.
Correo Compras also aims to stimulate consumer demand. The platform offers government subsidized installment purchase plans that allow payment over three, six, and twelve months.
As with every platform, the success of public platforms depends on their capacity to trigger direct and indirect network effects - meaning they gain additional value as more people use them. Can Correo Compras succeed, and thereby become a role model for other countries?
Unlike private platforms, in public platforms political motives could be decisive network effect drivers. Buying at Correo Compras could be seen as a way to reduce the power of tech companies, support the state's active participation in the economy, express support for the current administration or support the company's workers. In any case, it could become the first political grassroots action to engender platform network effects.
Data, planning, and surveillance
----------------------------------
Finally, could the state use direct access to market data differently than private tech giants? Correo Compras offers the Argentinean state an unprecedented opportunity: the chance to access continuous market data flows in real-time.
With the necessary algorithms and computing power, the state could significantly enhance its political action within and beyond e-commerce. It could anticipate productive and market opportunities and evaluate the impact of related policies in real-time.
Data could be used for democratic planning, minimizing waste and respecting the ecological capacities of the planet. We could envision a sustainable scenario where data is used to identify and fulfill the needs of the population instead of further concentrating wealth and income.
How the government will guarantee digital security and overcome surveillance capitalism are unavoidable matters that remain unclear. Besides Correo Compras, Argentina has also witnessed the emergence of cooperative marketplaces, which are another alternative to tech giants. Could they all be part of an opportunity to use data for the public good and not to control, modify, and ultimately induce behaviors that favor the concentration of knowledge and wealth?
Besides this open question, Argentina's experience opens a window of opportunity to go beyond regulation. Other governments, not only the United States but also the United Kingdom and the European Union that depend centrally on Amazon, should keep a close eye on public platform initiatives when thinking about alternatives for their own countries.
Twenty-first century industrial policy cannot be detached from the digital economy. In this respect, Correo Compras could become an important turning point.
###
[We've got a newsletter for everyone]()
Whatever you're interested in, there's a free openDemocracy newsletter for you.
[Have a look]()
Read more
===========
Get our weekly email
Enter your email address
Submit
###
Read more
* [[![]()](/en/oureconomy/united-nations-food-summit-corporations-small-farmers-big-ag/)](/en/oureconomy/united-nations-food-summit-corporations-small-farmers-big-ag/)
Published in:
[ourEconomy](/en/oureconomy/)
[UN should be learning from sustainable food producers - not hosting Big Ag](/en/oureconomy/united-nations-food-summit-corporations-small-farmers-big-ag/)
Written by: Shalmali Guttal
[All articles by:
Shalmali Guttal](/en/author/shalmali-guttal/)
Written by: Sofia Monsalve
[All articles by:
Sofia Monsalve](/en/author/sofia-monsalve/)
* [[![]()](/en/oureconomy/care-crisis-workers-organising-labour-strikes-cost-of-living/)](/en/oureconomy/care-crisis-workers-organising-labour-strikes-cost-of-living/)
Published in:
[ourEconomy](/en/oureconomy/)
[How to beat the cost-of-living crisis? Join the care workers fighting back](/en/oureconomy/care-crisis-workers-organising-labour-strikes-cost-of-living/)
Written by: Lydia Hughes
[All articles by:
Lydia Hughes](/en/author/lydia-hughes/)
Written by: Jamie Woodcock
[All articles by:
Jamie Woodcock](/en/author/jamie-woodcock/)
* [[![]()](/en/oureconomy/care-crisis-urban-design-cars-tenement-security-communal-space/)](/en/oureconomy/care-crisis-urban-design-cars-tenement-security-communal-space/)
Published in:
[ourEconomy](/en/oureconomy/)
[How the design of our cities is making the care crisis worse](/en/oureconomy/care-crisis-urban-design-cars-tenement-security-communal-space/)
Written by: Adam Ramsay
[All articles by:
Adam Ramsay](/en/author/adam-ramsay/)
* [[![]()](/en/oureconomy/climate-crisis-care-crisis-global-warming-wealth-industrialisation/)](/en/oureconomy/climate-crisis-care-crisis-global-warming-wealth-industrialisation/)
Published in:
[ourEconomy](/en/oureconomy/)
[Why the climate crisis is a care crisis - and how we can avert it](/en/oureconomy/climate-crisis-care-crisis-global-warming-wealth-industrialisation/)
Written by: Harpreet Kaur Paul
[All articles by:
Harpreet Kaur Paul](/en/author/harpreet-kaur-paul/)
[View all in ourEconomy](/en/oureconomy/)
Economics journalism that puts people and planet first.
Get the ourEconomy newsletter
Join the conversation: subscribe below
Enter your email address
-
Comments
----------
We encourage anyone to comment, please consult
[the oD commenting guidelines](/en/opendemocracy-comment-guidelines/)
if you have any questions.
Please enable JavaScript to view the
[comments powered by Disqus.]()
###
Related
* [nationalization](/en/tagged/nationalization/)
* [Amazon](/en/tagged/amazon/)
* [Public ownership](/en/tagged/public-ownership/)
* [coronavirus](/en/tagged/coronavirus/)
* [Economics](/en/tagged/economics/)
* [Latin America](/en/tagged/latin-america/)
* [Politics & activism](/en/tagged/politics-activism/)
* [United States & Canada](/en/tagged/united-states-canada/)
![Creative Commons Attribution-NonCommercial 4.0]()
This article is published under a
[Creative Commons Attribution-NonCommercial 4.0 International licence]()
. If you have any queries about republishing please
[contact us]()
. Please check individual images for licensing details.
[All our projects](/en/all-our-projects/)
* [openDemocracy Facebook]()
* [openDemocracy Twitter]()
* [openDemocracy Instagram]()
* [openDemocracy Youtube]()
©️ openDemocracy 2023
* [About](/en/about/)
* [People](/en/team/)
* [Contact](/en/contact/)
* [Write for us](/en/write-for-us/)
* [Jobs](/en/opportunities-at-opendemocracy/)
* [Privacy notice](/en/privacy-notice/)
Audio available
Bookmark
Check
Language
Close
Comments
Download
Facebook
Link
Email
Newsletter
Newsletter
Play
Print
Share
Twitter
Youtube
Search
Instagram
WhatsApp
yourData