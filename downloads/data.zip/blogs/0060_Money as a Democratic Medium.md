Money as a Democratic Medium 2.0 - Just Money
[Skip to content](#content)
[Just Money]()
=====================================
Menu
* [MDM 2.0]()
* [About]()
+ [Meet Us!]()
+ [Join Us!]()
+ [Trivia Contests]()
* [Scholarship]()
+ [Policy Spotlights]()
+ [Current Scholarship]()
+ [Emerging Scholarship]()
* [Roundtables]()
* [News]()
* [Teaching]()
+ [Syllabi]()
+ [Teaching Money 20/21]()
+ [Conference Archive]()
+ [In the Arts]()
* [Twitter]()
Conference: June 15-17, 2023
Money as a Democratic Medium 2.0
=====================================================================
[![Print Friendly, PDF & Email]()
![Print Friendly, PDF & Email]()](# "Printer Friendly, PDF & Email")
[![]()
![]()]()
Money as a Democratic Medium 2.0
==================================
June 15-17, 2023
[Cambridge and Hamburg Schedules Updated!]()
Cambridge, MA
---------------
#####
June 15-17, 2023
#####
HARVARD LAW SCHOOL
#####
Sponsored by: INET; PERI, University of Massachusetts, Amherst; LPE@HLS; APPEAL; Harvard Law School
Hamburg, Germany
------------------
#####
June 15-16, 2023
THE NEW INSTITUTE AND HAMBURG INSTITUTE FOR SOCIAL RESEARCH
#####
Sponsored by: Hamburg Institute for Social Research and THE NEW INSTITUTE; University of Wurzburg
Keynote Speakers
------------------
![The Honourable Mia Amor Mottley, Q.C., M.P.]()
![The Honourable Mia Amor Mottley, Q.C., M.P.]()
#####
**[The Honorable Mia Amor Mottley, Q.C., M.P.]()**
Prime Minister of Barbados
Keynote Speakers
------------------
![Saule Omarova, Professor of Law.]()
![Saule Omarova, Professor of Law.]()
#####
**[Professor Saule Omarova]()**
Cornell Law School
**[MDM2 Home]()**
|
[Overview]()
|
[**Logistics**]()
Cambridge ::
[Schedule & Links]()
|
[Papers]()
|
[Registration]()
Hamburg ::
[Schedule]()
|
[Abstracts]()
|
[Registration]()
(Online only)
We
are delighted to announce Money as a Democratic Medium 2.0. The Conference will be held in two locations in order to maximize participation while minimizing carbon impacts: Cambridge, MA (Harvard Law School, June 15-17, 2023) and Hamburg, Germany (the Hamburg Institute for Social Research and THE NEW INSTITUTE, June 15-16, 2023). The Conference is open to all students of money, credit, and finance, the monetary system, and the modern economy, including members of the public. We will offer robust online access and we encourage distant participants to join us virtually.
The Conference includes opportunities for specialized exchange in panel sessions and plenary events of interest to the broad audience.
Conference Coordinator: Susan Smith -
###
Search
Search for:
* [Twitter]()
Loading Comments...
Write a Comment...
Email (Required)
Name (Required)
Website
###