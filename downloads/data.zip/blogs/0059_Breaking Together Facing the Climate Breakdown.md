Breaking Together by Jem Bendell - Audiobook - Audible.co.uk
[![audible, an amazon company]()](/)
* [Sign In]()
* [Browse](#)
###
Audiobook Categories
+ [All Categories](/categories)
+ [Fiction](/cat/Literature-Fiction-Audiobooks/)
+ [Mystery, Thriller & Suspense](/cat/Mystery-Thriller-Suspense-Audiobooks/)
+ [Science Fiction & Fantasy](/cat/Science-Fiction-Fantasy-Audiobooks/)
+ [Personal Development](/cat/Health-Wellness-Audiobooks/)
+ [Biographies & Memoirs](/cat/Biographies-Memoirs-Audiobooks/)
+ [Children's Audiobooks](/cat/Childrens-Audiobooks-Audiobooks/)
+ [History](/cat/History-Audiobooks/)
###
Popular Lists
+ [Best Sellers](/adblbestsellers)
+ [New Releases](/newreleases)
+ [Podcasts](/ep/podcasts)
+ [Audible Originals](/ep/audible-originals)
+ [Sleep](/ep/sleep-for-members)
+ [Audible Theatre](/ep/theatre)
+ [Coming Soon](/coming-soon)
###
Explore Audible
+ [Membership Benefits](/ep/memberbenefits)
+ [Audible Plus Catalogue](/ep/audible-plus-member-benefit)
+ [Redeem a Promo Code](/promo/redemption)
+ [Gift Centre](/ep/giftcentre)
+ [Help Centre]()
No results
Suggested Searches
Listen free for 30 days
-------------------------
![Breaking Together cover art]()
Sample
![]()
* Breaking Together
===================
* A Freedom-Loving Response to Collapse
* By:
[Jem Bendell](/author/Jem-Bendell/B0C1K8YMXZ)
* Narrated by:
[Matthew Slater](/search?searchNarrator=Matthew+Slater)
* Length:
18 hrs and 13 mins
* 5.0 out of 5 stars
5.0
(2 ratings)
Add to basket failed.
-----------------------
Please try again later
Add to wishlist failed.
-------------------------
Please try again later
Remove from wishlist failed.
------------------------------
Please try again later
Adding to library failed
--------------------------
Please try again
Follow podcast failed
-----------------------
Unfollow podcast failed
-------------------------
[Try for PS0.00](/subscription/confirmation?membershipAsin=B07BVZK3XQ&productAsin=B0C8PTD9ZL&buyingOptionId=eyJvZmZlclR5cGUiOiJVUFNFTEwiLCJwcmljZSI6eyJjdXJyZW5jeSI6eyJjb2RlIjoiR0JQIiwidmFsdWUiOjAuMDB9LCJfX2NsYXNzIjoiY29tLmFtYXpvbi5hdWRpYmxlYnV5aW5nb3B0aW9uc3NlcnZpY2UuQ29udGVudFByaWNlIn0sInByb2dyYW1zIjpbIlBSRU1JVU0iXSwicmFuayI6NDUwLCJjbGllbnRDb250ZXh0Ijp7ImNsaWVudElkIjoiVW5rbm93biJ9LCJxdWFsaWZpY2F0aW9uIjp7ImN1c3RvbWVyRWxpZ2liaWxpdHkiOnsiYmVuZWZpdElkIjoiT25lQ3JlZGl0TW9udGhseUJlbmVmaXQiLCJhZEZyZWVFbGlnaWJsZSI6ZmFsc2UsImJlbmVmaXRDcml0ZXJpYSI6W3sibmFtZSI6InByZW1pdW1TdWJzY3JpcHRpb24iLCJ2YWx1ZSI6IkIwN0JWWkszWFEiLCJ2YWx1ZXMiOlsiQjA3QlZaSzNYUSJdfV19LCJjb250ZW50RWxpZ2liaWxpdHkiOnsiY2F0YWxvZ0lkIjoiQXVkaW9Cb29rcyIsImNhdGFsb2dUeXBlIjoiQ29udGVudERlbGl2ZXJ5VHlwZSJ9fSwiYmVuZWZpdElkIjoiT25lQ3JlZGl0TW9udGhseUJlbmVmaXQiLCJvZmZlclR5cGVJZCI6Ik9ORV9DUkVESVRfTU9OVEhMWV9VUFNFTExfVFJJQUwiLCJ1cHNlbGxJbmZvIjp7ImFzaW4iOiJCMDdCVlpLM1hRIiwidHlwZSI6Ik1FTUJFUlNISVAiLCJwcmljZSI6eyJwcmljZVNjaGVkdWxlcyI6W3sidGVybSI6eyJzdGFydCI6MSwiZW5kIjoxLCJmcmVxdWVuY3kiOiIzMCIsImZyZXF1ZW5jeV91bml0IjoiZGF5cyJ9LCJjdXJyZW5jeSI6eyJjb2RlIjoiR0JQIiwidmFsdWUiOjAuMDB9fSx7InRlcm0iOnsic3RhcnQiOjIsImVuZCI6MCwiZnJlcXVlbmN5IjoiMSIsImZyZXF1ZW5jeV91bml0IjoibW9udGhzIn0sImN1cnJlbmN5Ijp7ImNvZGUiOiJHQlAiLCJ2YWx1ZSI6Ny45OX19XSwiX19jbGFzcyI6ImNvbS5hbWF6b24uYXVkaWJsZWJ1eWluZ29wdGlvbnNzZXJ2aWNlLk1lbWJlcnNoaXBQcmljZSJ9LCJtZW1iZXJzaGlwT2ZmZXJUeXBlIjoiRnJlZVRyaWFsIiwibWVtYmVyc2hpcEdyb3VwVHlwZSI6IkJhc2ljIiwibWVtYmVyc2hpcFByb2dyYW1UeXBlIjoiRGVmYXVsdCJ9fQ==)
![Prime logo]()
Prime member exclusive:
pick 2 free titles with trial.
Thousands of incredible audiobooks and podcasts to take wherever you go.
Immerse yourself in a world of storytelling with the Plus Catalogue - unlimited listening to thousands of select audiobooks, podcasts and Audible Originals.
PS7.99/month after 30 days. Renews automatically. See
[here]()
for eligibility.
![Breaking Together cover art]()
Breaking Together
===================
By:
Jem Bendell
Narrated by:
Matthew Slater
[Try for PS0.00](/subscription/confirmation?membershipAsin=B07BVZK3XQ&productAsin=B0C8PTD9ZL&buyingOptionId=eyJvZmZlclR5cGUiOiJVUFNFTEwiLCJwcmljZSI6eyJjdXJyZW5jeSI6eyJjb2RlIjoiR0JQIiwidmFsdWUiOjAuMDB9LCJfX2NsYXNzIjoiY29tLmFtYXpvbi5hdWRpYmxlYnV5aW5nb3B0aW9uc3NlcnZpY2UuQ29udGVudFByaWNlIn0sInByb2dyYW1zIjpbIlBSRU1JVU0iXSwicmFuayI6NDUwLCJjbGllbnRDb250ZXh0Ijp7ImNsaWVudElkIjoiVW5rbm93biJ9LCJxdWFsaWZpY2F0aW9uIjp7ImN1c3RvbWVyRWxpZ2liaWxpdHkiOnsiYmVuZWZpdElkIjoiT25lQ3JlZGl0TW9udGhseUJlbmVmaXQiLCJhZEZyZWVFbGlnaWJsZSI6ZmFsc2UsImJlbmVmaXRDcml0ZXJpYSI6W3sibmFtZSI6InByZW1pdW1TdWJzY3JpcHRpb24iLCJ2YWx1ZSI6IkIwN0JWWkszWFEiLCJ2YWx1ZXMiOlsiQjA3QlZaSzNYUSJdfV19LCJjb250ZW50RWxpZ2liaWxpdHkiOnsiY2F0YWxvZ0lkIjoiQXVkaW9Cb29rcyIsImNhdGFsb2dUeXBlIjoiQ29udGVudERlbGl2ZXJ5VHlwZSJ9fSwiYmVuZWZpdElkIjoiT25lQ3JlZGl0TW9udGhseUJlbmVmaXQiLCJvZmZlclR5cGVJZCI6Ik9ORV9DUkVESVRfTU9OVEhMWV9VUFNFTExfVFJJQUwiLCJ1cHNlbGxJbmZvIjp7ImFzaW4iOiJCMDdCVlpLM1hRIiwidHlwZSI6Ik1FTUJFUlNISVAiLCJwcmljZSI6eyJwcmljZVNjaGVkdWxlcyI6W3sidGVybSI6eyJzdGFydCI6MSwiZW5kIjoxLCJmcmVxdWVuY3kiOiIzMCIsImZyZXF1ZW5jeV91bml0IjoiZGF5cyJ9LCJjdXJyZW5jeSI6eyJjb2RlIjoiR0JQIiwidmFsdWUiOjAuMDB9fSx7InRlcm0iOnsic3RhcnQiOjIsImVuZCI6MCwiZnJlcXVlbmN5IjoiMSIsImZyZXF1ZW5jeV91bml0IjoibW9udGhzIn0sImN1cnJlbmN5Ijp7ImNvZGUiOiJHQlAiLCJ2YWx1ZSI6Ny45OX19XSwiX19jbGFzcyI6ImNvbS5hbWF6b24uYXVkaWJsZWJ1eWluZ29wdGlvbnNzZXJ2aWNlLk1lbWJlcnNoaXBQcmljZSJ9LCJtZW1iZXJzaGlwT2ZmZXJUeXBlIjoiRnJlZVRyaWFsIiwibWVtYmVyc2hpcEdyb3VwVHlwZSI6IkJhc2ljIiwibWVtYmVyc2hpcFByb2dyYW1UeXBlIjoiRGVmYXVsdCJ9fQ==)
PS7.99/month after 30 days. Renews automatically. See
[here]()
for eligibility.
[Buy Now for PS22.89]( "Buy Breaking Together now")
Buy Now for PS22.89
Confirm Purchase
No valid payment method on file.
----------------------------------
[Add payment method](#)
[Switch payment method](#)
We are sorry. We are not allowed to sell this product with the selected payment method
----------------------------------------------------------------------------------------
[Switch payment method](#)
![]()
**Pay using**
card ending in
[Switch payment method](#)
By completing your purchase, you agree to Audible's
[Conditions of Use]()
and authorise Audible to charge your designated card or any other card on file. Please see our
[Privacy Notice]()
,
[Cookies Notice](/legal/cookies-and-advertising)
and
[Interest-based Ads Notice]()
.
Cancel
###
Copy Link
Copy Link
Listeners also enjoyed...
---------------------------
[![Hothouse Earth cover art]()](/pd/Hothouse-Earth-Audiobook/B0BT278MRS?plink=ZZhPv5AsZQbtydoK)
Sample
![]()
[![Doughnut Economics cover art]()](/pd/Doughnut-Economics-Audiobook/B077G3WG7T?plink=ZZhPv5AsZQbtydoK)
Sample
![]()
[![Less Is More cover art]()](/pd/Less-Is-More-Audiobook/?plink=ZZhPv5AsZQbtydoK)
Sample
![]()
[![The Uninhabitable Earth cover art]()](/pd/The-Uninhabitable-Earth-Audiobook/?plink=ZZhPv5AsZQbtydoK)
Sample
![]()
[![The Dawn of Everything cover art]()](/pd/The-Dawn-of-Everything-Audiobook/?plink=ZZhPv5AsZQbtydoK)
Sample
![]()
[![The Book of Wilding cover art]()](/pd/The-Book-of-Wilding-Audiobook/B0BY3CQJY9?plink=ZZhPv5AsZQbtydoK)
Sample
![]()
[![The Locust and the Bee cover art]()](/pd/The-Locust-and-the-Bee-Audiobook/B00CJJC7MO?plink=ZZhPv5AsZQbtydoK)
Sample
![]()
[![Reason in a Dark Time cover art]()](/pd/Reason-in-a-Dark-Time-Audiobook/B00MYF9MV2?plink=ZZhPv5AsZQbtydoK)
Sample
![]()
[![Peak Everything cover art]()](/pd/Peak-Everything-Audiobook/B0052FRO0C?plink=ZZhPv5AsZQbtydoK)
Sample
![]()
[![The End of the World Is Just the Beginning cover art]()](/pd/The-End-of-the-World-Is-Just-the-Beginning-Audiobook/B09CSGSQLX?plink=ZZhPv5AsZQbtydoK)
Sample
![]()
[![The Bridge at the End of the World cover art]()](/pd/The-Bridge-at-the-End-of-the-World-Audiobook/B004EVX8DM?plink=ZZhPv5AsZQbtydoK)
Sample
![]()
[![The Great Un-Reset cover art]()](/pd/The-Great-Un-Reset-Audiobook/B0BZ6D8NF5?plink=ZZhPv5AsZQbtydoK)
Sample
![]()
[![The Future Is Degrowth cover art]()](/pd/The-Future-Is-Degrowth-Audiobook/B0C1TF8RWX?plink=ZZhPv5AsZQbtydoK)
Sample
![]()
[![The Best of Times, the Worst of Times cover art]()](/pd/The-Best-of-Times-the-Worst-of-Times-Audiobook/?plink=ZZhPv5AsZQbtydoK)
Sample
![]()
[![Brighter cover art]()](/pd/Brighter-Audiobook/B0BQ8NTDLB?plink=ZZhPv5AsZQbtydoK)
Sample
![]()
[![Sustainability cover art]()](/pd/Sustainability-Audiobook/170528230X?plink=ZZhPv5AsZQbtydoK)
Sample
![]()
Summary
---------
The collapse of modern societies has begun. That is the conclusion of two years of research by the interdisciplinary team behind
*Breaking Together*
.
How did it come to this? Because monetary systems caused us to harm each other and nature to such an extent it broke the foundations of our societies. So what should we do? This audiobook describes people allowing the full pain of our predicament to liberate them into living more courageously and creatively. They demonstrate we can be breaking together, not apart, in this era of collapse.
Jem Bendell argues that reclaiming our freedoms is essential to soften the fall and regenerate the natural world. Escaping the efforts of panicking elites, we can advance an ecolibertarian agenda for both politics and practical action in a broken world.
©️2023 Jem Bendell (P)2023 Jem Bendell
* Unabridged
Audiobook
* Categories:
[Politics & Social Sciences](/cat/Politics-Social-Sciences-Audiobooks/)
[Freedom & Security](/cat/Politics-Government/Freedom-Security-Audiobooks/)
[Politics & Government](/cat/Politics-Social-Sciences/Politics-Government-Audiobooks/)
[Philosophy](/cat/History-Philosophy/Philosophy-Audiobooks/)
Show More
Show Less
What listeners say about Breaking Together
--------------------------------------------
Average customer ratings
Overall
* 5 out of 5 stars
5.0 out of 5.0
* 5 Stars
2
* 4 Stars
0
* 3 Stars
0
* 2 Stars
0
* 1 Stars
0
Performance
* 5 out of 5 stars
5.0 out of 5.0
* 5 Stars
2
* 4 Stars
0
* 3 Stars
0
* 2 Stars
0
* 1 Stars
0
Story
* 5 out of 5 stars
5.0 out of 5.0
* 5 Stars
2
* 4 Stars
0
* 3 Stars
0
* 2 Stars
0
* 1 Stars
0
Reviews - Please select the tabs below to change the source of reviews.
-------------------------------------------------------------------------
Audible.co.uk reviews
-----------------------
Audible.com reviews
---------------------
Amazon reviews
----------------
Sort by:
Most Helpful
Most Recent
Filter by:
All stars
5 star only
4 star only
3 star only
2 star only
1 star only
* Overall
5 out of 5 stars
* Performance
5 out of 5 stars
* Story
5 out of 5 stars
[![Profile Image for Meg22]()](/listener/amzn1.account.AEYPZNIMS5FGKXRTJWIJMXN3SXRQ)
* [Meg22](/listener/amzn1.account.AEYPZNIMS5FGKXRTJWIJMXN3SXRQ)
* 27-07-23
###
Highly recommend. Content gives superb value
A vast amount of high quality research and experience has gone into this book, and it provides a rich well of food for thought for anyone wanting to know more and/or adapt to the obvious collapse of multiple systems of modern society we are currently going through.
Narration is superb, and the index is very good, allowing you to easily find areas of particular interest.
* Overall
5 out of 5 stars
* Performance
5 out of 5 stars
* Story
5 out of 5 stars
[![Profile Image for Ted Truth]()](/listener/amzn1.account.AGSVZJAHJEB3LS5LUGKKIPXSXDRA)
* [Ted Truth](/listener/amzn1.account.AGSVZJAHJEB3LS5LUGKKIPXSXDRA)
* 08-07-23
###
Truth
Brilliant, essential, inspiring & life-affirming! That's what the truth - so rare - can do. An extremely clearly argued explanation of our human predicament. A very high quality piece of agonising scholarship, from an author (and team of researchers) with very broad and highly relevant 'generalist' as well as specialist overview. Anyone who disagrees with the conclusions within this book needs to explain equally clearly why and how and show their workings. This is a wake up call sadly too late to prevent the collapse of societies and mass extinction of species (etc), but it does point to a positive way of being a human throughout what remains. Well narrated too. I thank the author and all involved from my heart.
Sort by:
Most Helpful
Most Recent
Filter by:
All stars
5 star only
4 star only
3 star only
2 star only
1 star only
* Overall
5 out of 5 stars
* Performance
5 out of 5 stars
* Story
5 out of 5 stars
![Profile Image for Iamiam]()
* Iamiam
* 11-07-23
###
Bold, honest, and I'm afraid Bendell is right.
The truth is not easy to accept, espy when it sucks. Bendell explains why he's right and helps make it all digestible.
* [Contact Us](/contactus)
* [Help]()
* [Business Enquiries](/ep/contact-us)
* [Affiliates](/ep/affiliate-intro)
* [UK Modern Slavery Statement]()
* [Community Engagement]()
* [Audible Mobile Apps](/howtolisten)
* [Gift Centre](/ep/giftcentre)
* [Redeem a Promotional Code](/promo/redemption)
* [Plus Catalogue](/ep/audible-plus-member-benefit)
* [Mobile Site](/?bp_ua=false)
* [Best Sellers](/adblbestsellers)
* [New Releases](/newreleases)
* [Foreign Language](/ep/foreign_language)
* [Mystery, Thriller & Suspense](/cat/Mystery-Thriller-Suspense-Audiobooks/)
* [Science Fiction & Fantasy](/cat/Science-Fiction-Fantasy-Audiobooks/)
* [Road Trip Listens](/ep/road-trip)
* [Summer Listens](/ep/summer-listens)
* [History](/cat/History-Audiobooks/)
* [Biographies & Memoirs](/cat/Biographies-Memoirs-Audiobooks/)
* [Business & Careers](/cat/Business-Careers-Audiobooks/)
* [Health & Wellness](/cat/Health-Wellness-Audiobooks/)
* [Literature & Fiction](/cat/Literature-Fiction-Audiobooks/)
* [Children's Audiobooks](/cat/Childrens-Audiobooks-Audiobooks/)
* [Comedy](/cat/)
©️ Copyright 1997 - 2023 Audible Ltd.
[Conditions of Use]()
[Privacy Notice]()
[Cookies](/legal-terms/cookieandinternet/ref=mn_anon-h_f6_ca?moduleId=201654420)
[Interest-Based Ads](/ep/interestbasedads)
[United Kingdom (English)]()