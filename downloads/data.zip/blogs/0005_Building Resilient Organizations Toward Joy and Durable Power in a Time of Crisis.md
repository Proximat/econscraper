Building Resilient Organizations: Toward Joy and Durable Power in a Time of Crisis | Convergence
[Skip to content](#main)
[Skip to footer](#footer)
[Convergence "C" logo with text, black
Convergence]()
#####
Menu
####
Making Waves
* [Racial Justice]( "Racial Justice")
* [Organizing Strategy]( "Organizing Strategy")
* [Leadership and Accountability]( "Leadership and Accountability")
* [Danger from the Right]( "Danger from the Right")
####
Sections
* [Latest]()
* [Podcasts]()
* [Videos]()
* [Donate Now]()
* [Buy the Book]()
####
Convergence
* [About]()
* [Contact]()
* [Submissions]()
* [Subscribe]()
* [xml version="1.0" encoding="utf-8"?
Find us on Facebook]( "Find us on Facebook")
* [xml version="1.0" encoding="utf-8"?
Find us on Instagram]( "Find us on Instagram")
* [xml version="1.0" encoding="utf-8"?
Find us on Twitter]( "Find us on Twitter")
* [xml version="1.0" encoding="utf-8"?
Find us on Youtube]( "Find us on Youtube")
#####
Search
Search
[Democracy]()
Building Resilient Organizations: Toward Joy and Durable Power in a Time of Crisis
====================================================================================
[![head shot of Maurice Mitchell, Working Families Party]()]()
by
[Maurice Mitchell]()
Article published:
November 29, 2022
![Read Maurice Mitchell]()
#####
Share
* [Share via Facebook
xml version="1.0" encoding="utf-8"?]()
* [Share via Twitter
xml version="1.0" encoding="utf-8"?]()
* [Share via Email
xml version="1.0" encoding="utf-8"?](/cdn-cgi/l/email-protection#ebd4b89e89818e889fd6a99e82878f82858cced9dbb98e988287828e859fced9dba4998c8a8582918a9f82848598ced8aaced9dbbf849c8a998fced9dba18492ced9db8a858fced9dbaf9e998a89878eced9dbbb849c8e99ced9db8285ced9db8aced9dbbf82868eced9db848dced9dba89982988298cd89848f92d6bf84ced9db8e8d8d8e889f829d8e8792ced9db8884859f8e858fced9db9c829f83ced9db998a8882989fced9a8ced9db8a9e9f838499829f8a99828a85ced9db8d8499888e98ced9a8ced9db849e99ced9db9c849980ced9db869e989fced9db898eced9db8a98ced9db9b849c8e998d9e87ced9db8a98ced9db9b8498988289878ec5ced9dba68a9e9982888eced9dba6829f88838e8787ced9db9e859b8a888098ced9db9f838eced9db9b998489878e8698ced9db849e99ced9db84998c8a8582918a9f82848598ced9db8a858fced9db86849d8e868e859f98ced9db8d8a888eced9a8ced9db828f8e859f828d828e98ced9db9e858f8e99879282858cced9db888a9e988e98ced9db8a858fced9db8884998eced9db9b998489878e8698ced9a8ced9db8a858fced9db9b99849b84988e98ced9db88848588998e9f8eced9db9884879e9f82848598c5ced9dbcedbaacedbaa839f9f9b98ced8aaced9adced9ad8884859d8e998c8e85888e868a8cc5888486ced9ad8a999f8288878e98ced9ad899e82878f82858cc6998e988287828e859fc684998c8a8582918a9f82848598c69f849c8a998fc6818492c68a858fc68f9e998a89878ec69b849c8e99c68285c68ac69f82868ec6848dc6889982988298ced9adced8ad9e9f86b498849e99888eced8afa884859d8e998c8e85888eced9dd9e9f86b4868e8f829e86ced8af8e868a8287ced9dd9e9f86b4888a869b8a828c85ced8afa884859d8e998c8e85888eced9a9b8838a998eced9a9a99e9f9f848598)
* Share via Copied Link
xml version="1.0" encoding="utf-8"?
* Share via Print
xml version="1.0" encoding="utf-8"?
To effectively contend with racist, authoritarian forces, our work must be as powerful as possible. Maurice Mitchell unpacks the problems our organizations and movements face, identifies underlying causes and core problems, and proposes concrete solutions.
###
[Building Resilient Organizations]()
####
A Convergence Series
[![]()]()
Maurice Mitchell unpacks the problems our organizations and movements face, identifies underlying causes and core problems, and proposes concrete solutions.
[Previous]()
[Next]()
'''
*Listen to this article [here]().*
*Lea este articulo [en espanol]()*.
*[Watch]() Maurice Mitchell talk about why and how he wrote this article.*
*Download a discussion guide for this article [here]().*
*Share the full series with your friends using [this link]().*
'''
Executives in professional social justice institutions, grassroots activists in local movements, and fiery young radicals on protest lines are all advancing urgent concerns about the internal workings of progressive spaces. The themes arising are surprisingly consistent. Many claim that our spaces are "toxic" or "problematic," often sharing compelling and troubling personal anecdotes as evidence of this. People in leadership are finding their roles untenable, claiming it is "impossible" to execute campaigns or saying they are in organizations that are "stuck."
A growing group of new organizers and activists are becoming cynical or dropping out altogether. Most read their experiences as interpersonal conflict gone awry, the exceptional dynamics of a broken environment or a movement that's lost its way. A "bad supervisor," a "toxic workplace," a "messy movement space," or a "problematic person with privilege" are just some of the refrains echoed from all corners of our movements. Individuals are pointing fingers at other individuals; battle lines are being drawn. Identity and position are misused to create a doom loop that can lead to unnecessary ruptures of our political vehicles and the shuttering of vital movement spaces.
Movements on the Left are driven by the same political and social contradictions we strive to overcome. We fight against racism, classism, and sexism yet battle inequity and oppression inside our movements. Although we struggle for freedom and democracy, we also suffer from tendencies toward abuse and domination. We promote leadership and courage by individuals, but media exposure, social media fame, and access to resources compromise activists. We draw from the courage of radical traditions but often lack the strategy or conviction to challenge the status quo. The radical demands that we do make are so regularly disregarded that it can feel as if we are shouting into the wind. Many of us are working harder than ever but feeling that we have less power and impact.
There are things we can and must do to shift movements for justice toward a powerful posture of joy and victory. Such a metamorphosis is not inevitable, but it is essential. This essay describes the problems our movements face, identifies underlying causes, analyzes symptoms of the core problems, and proposes some concrete solutions to reset our course.
Your inbox needs more left. Sign up for our newsletter.
Roots of the Crisis
=====================
This moment is one of multiple, overlapping crises: a global pandemic, rising authoritarianism, climate emergency, political violence, unprecedented economic inequality, and general precarity all exacerbate interpersonal tension points. Like the rest of society, our movements exist within a general climate of anxiety, despair, and anger without the necessary support to process such massive emotions, individually or in community. Recognizing the challenging terrain on which we struggle and grow can allow for more compassion for our comrades as well as clarity about the urgent mandate at hand.
Our current movement is ideologically underdeveloped and uneven. History can help us understand why. There has been a one-sided, often government-initiated effort to defang movements for justice: the brutal terrorism following Reconstruction, the Red Scare following the Bolshevik revolution in 1917, the dismantling of Pan-African nationalist movements in the 1920s, McCarthyism in the '50s, COINTELPRO in the '60s, and the war on militant Black liberation organizations well into the early '80s. Leaders have been jailed, killed, or co-opted; organizations have been invaded, dismantled, or neutralized. We have inherited this traumatic and often bloody legacy.
As a result of this rupture, over the past 50 years, many of our leaders have prioritized hard skills and pragmatism over developing their ideological orientation or running transformative campaigns. Other organizations have an ideological analysis but lack the skills to develop an effective strategy and execute a campaign in a way that builds large bases.
Current conditions also contribute to the organizational tensions under which we operate. These include but are not limited to:
* A crisis of institutional legitimacy after 40 years of neoliberalism
* A reckoning with institutional power and cultural privilege shaped by social movements like the #MeToo Movement and the Movement for Black Lives
* The structural and ideological limitations of 501(c)3 non-profits in terms of their subservience to funding sources and resulting incompatibility with power building
* The expansion of corporate and billionaire power, popularization of ethnonationalist ideologies, and election of right-wing governments, all of which create severe economic volatility for working class and poor people
* The occupation of leadership roles by Black people, people of color, immigrants, women, queer and gender non-conforming people, or people who come from non-elite backgrounds without sufficient institutional support
* The elevation of leaders to their positions based on exceptional oratory and organizing ability rather than management skills
* The lack of management philosophy, theory of organizational design, or model of collective labor in both non-profits and informal spaces
Common Trends
================
Here are some common tendencies that flow from the larger conditions we find ourselves in and the fallacies underlying those tendencies.
###
I. Neoliberal Identity
####
Definition
Using one's identity or personal experience as a justification for a political position. You may hear someone argue, "As a working-class, first-generation American, Southern woman...I say we have to vote no." What's implied is that one's identity is a comprehensive validator of one's political strategy--that identity is evidence of some intrinsic ideological or strategic legitimacy. Marginalized identity is deployed as a conveyor of a strategic truth that must simply be accepted. Likewise, historically privileged identities are essentialized, flattened, and frequently--for better or worse-- dismissed.
####
Fallacies
To be clear, personal identity and individual experience are important. And while it is true that the "personal is political," the personal cannot trump strategy nor should it overwhelm the collective interest. Identity is too broad a container to predict one's politics or the validity of a particular position. There are
[over 40 million]()
Black folk in the US. Some have great politics, some do not. One's racial or gender identity, sex, or membership in any marginalized community is, in and of itself, insufficient information to position someone in leadership or mandate that their perspective be adopted.
People with marginal identities, as human beings, suffer all the frailties, inconsistencies, and failings of any other human. Genuflecting to individuals solely based on their socialized identities or personal stories deprives them of the conditions that sharpen arguments, develop skills, and win debates. We infantilize members of historically marginalized or oppressed groups by seeking to placate or pander instead of being in a right relationship, which requires struggle, debate, disagreement, and hard work. This type of false solidarity is a form of charity that weakens the individual and the collective. Finding authentic alignment and solidarity among diverse voices is serious labor. After all, "steel sharpens steel."
Neoliberal identity politics strips from identity politics a focus on collective power or a political project and demand. What's left is a narrow tool used as a personal cudgel or, as Barbara Smith
[has said]()
, "It's like they've taken the identity and left the politics on the floor." It should be noted that we have already seen this tactic used against us
[on the Left]()
and
[the Right]()
in the fight for racial and economic justice. Identity in this context reaffirms the individualistic principles of neoliberalism instead of challenging them.
###
**II.**
Maximalism
####
Definition
Considering anything less than the most idealistic position as a betrayal of core values and evidence of corruption, cowardice, lack of commitment, or vision. Relatedly, a righteous refusal to engage with people who do not already share our views and values.
Maximalist arguments may present themselves as debates around principles, tactics, and language or as the performance of solidarity with individuals, identity groups, and other movements. Maximalism demands that allies embrace certain tactics or positions as a test of alignment.
####
Fallacies
Maximalism ignores the fact that the value of any tactic -- or the appropriateness of any demand -- must be evaluated within a larger strategy grounded in a power analysis. Sometimes tactics and demands help build power and sometimes they don't. Taken alone, they are not an adequate tool to test for alignment.
The simple reason is that there are not enough people who are already 100% aligned. Our organizations and movements need to
*grow*
. Holding on to tactics and overly idealistic demands that keep us small but pure ignores the basic strategic imperative of building power. We should of course be skeptical of those who demand too little and tell our movements to set their sights too low. But we should not mistake putting forward anything less than our most ambitious aspirations for an act of cowardice. In fact, it might reflect a sober assessment of our own power or advance a longer term strategy.
Maximalist thinking is particularly pernicious when it is used to justify not doing the basic work of organizing: talking to lots of different kinds of people on the doors, in their homes, and in their workplaces. We need to meet people where they are, build relationships, and move them into action. The work of organizing and base building also disciplines our tactics by grounding them in the needs and demands of our people.
Our opponents are formidable and dangerous. We must assess the power we actually have at all times and in every circumstance so that we don't either leave power on the table or overreach and come up empty. Sometimes, our assessment will reveal the need for us to build tactical and strategic coalitions that share broad -- though not identical -- goals to fight our opponents. That requires us to sharpen our skills at debate and internal democracy so that we are in a position to lead a united front against rising authoritarianism. When we organize and win material change with and for our people, we expand our base and create more power. In this way, the demands we make tomorrow can be more ambitious than the ones we make today.
###
**III.**
Anti-Leadership Attitudes
####
**Definition**
Holding skepticism of leadership as a rule. Questioning the authority, legitimacy, and competence of those with positional, perceived, or other forms of power. Therefore, all decisions made by leadership are subject to broad-based skepticism and mistrust. Valuing expertise and experience is challenged as potentially elitist. Professionalization is cited as a problematic aspect of how leadership and power are meted out. Anti-intellectualism is promoted as an egalitarian appreciation of more informal forms of skill or knowledge. This is not to be confused with a healthy skepticism of authority and leadership, including within movement spaces.
####
**Fallacies**
To be clear, abuse of authority, corruption, and the arbitrary concentration of power are real problems that have gone unexamined in years past. We should credit those people--many of them newer and younger to the work--who are shining a light on systemic issues and the deep harm they cause to individuals and the power we seek. However, a reflexively anti-leadership orientation is an overcorrection that doesn't make room for the existence of principled, responsive, accountable, and democratic leadership or for the ability of anyone in a leadership position to build strong movements, organizations, or workplaces.
Social change work requires experience, rigor, and study. It can take years of development to grow into a skillful organizer, strategist, communicator, campaign manager, or facilitator. Although talented people can rapidly develop skills, many capacities only develop over time. For example, judgment, relationship building, emotional maturity, and landscape awareness (including the knowledge of what you don't know) deepen with experience.
"Professionalization" and experience are two different things that should not be conflated. Most organizers historically and globally have not been developed through professional pipelines. However, all skilled organizers--professional or otherwise--have rigorously honed those skills over time through study and practice.
Pretending formal leadership doesn't exist can obscure hierarchies and create centers of informal power. Formal leadership, when healthy, provides clarity and transparency, which leads to greater accountability. This in turn fosters more avenues for support to develop new leadership.
Finally, there is a very real intellectual component to this work. The idea that working people do not or cannot engage in intellectual work is truly elitist and has not been my experience.
###
**IV.**
Anti-Institutional Sentiment
####
**Definition**
Reflexively disdaining institutions and organizations as inherently oppressive and antiquated, including the institution one may be associated with. This point of view casts institutions themselves as the problem, even those with a social change mission.
####
**Fallacies**
We all have examples of bloated, aimless, top-heavy, or simply irrelevant institutions that take space, hoard power, and demonstrate little impact. Even institutions that begin as disruptors of the status quo can slow-walk toward conservatism, disconnection, bureaucracy, irrelevance, and inefficiency. In fact, given the system of capitalism our institutions are navigating, if we are not mindful of these realities, we risk falling into them.
Despite those common pitfalls, we need institutions for a powerful and durable movement. Organizations and institutions are political vehicles. They are also spaces where individuals develop skills, connection, and ideological alignment. Institutions transmit knowledge, hold strategy, and cultivate power. Atomized individuals that loosely assemble cannot do this at the scale needed to take on entrenched power.
Arguing for doing away with political vehicles without offering a viable replacement demonstrates a lack of a power analysis. The most organized forces can leverage crisis, so how can our movements win in moments of crisis if we relinquish our organized vehicles? When our opposition possesses disciplined and organized institutions at the ready to fill power vacuums, what does it mean to unilaterally disarm?
Instead, movement institutions should have a self-aware practice of mitigating the worst impulses of institutional drift while maximizing the strengths of people-focused infrastructure.
###
**V.**
Cherry-Picking Arguments
####
**Definition**
Using incoherent or decontextualized arguments and perspectives to add perceived legitimacy to a position or oneself.
For example, using the term "intersectionality" to, let's say, defend edits to a press statement. Or employing the Audre Lorde quote, "Caring for myself is not self-indulgence...," to give gravitas to a desire to stay home from an action or take off time that you've earned and deserve as a worker. Or arming yourself with the concept "small is all" from adrienne maree brown's
[Emergent Strategy]()
framework--outside of its global fractal context--to resist taking responsibility for a larger scale intervention or growing your community group into a mass organization.
This tendency presents itself in language as well. Certain phases and words carry cultural currency and cachet. We often find words like "revolutionary" employed non-ironically in the service of bourgeois individualistic demands. Decontextualized or uncritical use of intellectual material, like the Tema Okun essay on
[white supremacy culture]()
, has at times served to challenge accountability around metrics and timeliness or the use of written language. Yet metrics and timeliness--and the ability to communicate in writing--are not in and of themselves examples of white supremacy.
####
**Fallacies**
It's easier to use language and cultural references that signify an ideological inclination than to actually study and practice a particular framework. However, such loose ideological signaling can lead to incoherence. This practice can devolve legitimate frameworks, concepts, and language into tools for individuals to virtue signal or provide weight to an argument that does not stand on its own premises. It should be noted that it is popular to borrow catchphrases and quotes from Black feminists, theorists, thinkers, and collectives in particular. This is especially pernicious when the arguments those thinkers developed are hijacked and flattened by those seeking personal benefit or legitimacy.
The profligate and unexamined use of social media has amplified this particular trend. These platforms--owned and controlled by megacorporations--reward us for our ability to articulate or reshare the sharpest, pithiest, pettiest, most polemic, or most engaging "content." There is no premium on nuance, accuracy, and context. There is little room for low-ego information sharing or curious and grounded political education. These platforms are ideal for, and give immediate reward to, uninformed cherry-picking, self-aggrandizement, competition, and conflict.
We are learning the damaging lesson that the performance of profundity can supercharge our arguments and points of view while obscuring scrutiny or accountability. In the worst cases, such practices weaken our work. At the same time, the instinct to reach for a high-minded theory when a simple request will do can overlook the power we have to set personal boundaries. For example, "I need to take personal time" is a complete and worthy statement. We are enough, and our desires and boundaries matter on their own.
###
**VI.**
Glass Houses
####
**Definition**
Insisting that change on an interpersonal or organizational level must occur before it is sought or practiced on a larger scale.
####
Fallacies
This point of view does not adequately consider the possibility that internal contradictions are the byproduct of external forces or that efforts to address internal and external challenges can run concurrently rather than sequentially. Both/and thinking is key here.
A glass houses approach prioritizes perfection (usually of a small group of people) over progress (on a societal level) by establishing unattainable tests that can consume individuals and organizations in a journey toward personal or organizational perfection at the detriment of broad and urgent change. This fixation with small utopianism can be both frustrating and unfulfilling. I would argue that "doing the work" should be viewed as ongoing day-to-day practice. This requires deep commitment to sharpening internal practices and culture as well as to improving and evaluating on a continuum.
###
**VII.**
The Small War
####
Definition
Elevating the power dynamics at play among actors internal to a movement over the larger power dynamics in society. In nonprofits or social justice organizations, this often takes the shape of focusing on tensions playing out between junior staff and leadership. In social movements, it may show up as conflicts between movement formations, sectarian ideological groupings, or movement leaders.
In prioritizing the small war, one accepts the notion that all sites of struggle are equal and that "making change wherever you are" includes addressing the demands placed on you as a functionary of a small nonprofit or a local activist in a community group. Refusal to wage the small war may therefore be seen as shirking a vital responsibility to maintain egalitarian power relations. Because proximity becomes the most important factor in deciding where to take action, this thinking often lacks a structural and systemic analysis of oppression and can feed or be fed by disproportionality (or the inability to identify the scale of the problem, further defined below). Small war thinking draws false equivalencies and teaches misassessments of power. The small war puts the "glass houses" framework into action.
####
Fallacies
The most accessible and manageable action is by no means the most consequential. A key part of strategy is assessing the relative impact of an intervention. The small war ignores that crucial step and can therefore lead organizers to prioritize a relatively small internal quarrel over, say, a corporate campaign or structural power fight. Some may even halt a structural power play by a movement or organization to pursue an internal power struggle.
These battles can implode and rupture institutions, leaving constituencies with less institutional power to wage the broader struggle.
Both/and is again a key concept here. We can address issues and challenges close to us while prioritizing the larger fight. This means making a commitment to broader objectives and the viability of the political vehicle even as you critique and improve that vehicle.
To be clear, we must not ignore problems or conflict simply because they are small, internal, or relatively parochial. In fact, I would argue that fighting for larger change is the most compelling reason to advance shifts to the internal workings of an organization. Small problems become large when unattended or dismissed. However, we must put them in proper context and stay focused on our north star. In other words, engaging in small internal debates
*for*
the larger fight.
The
[principled struggle]()
framework, beautifully articulated by N'Tanya Lee of Leftroots, is a more productive approach to managing internal differences. Grounded in a shared power analysis, north star, and commitment to a political project, we can sweat the small stuff in ways that maintain focus on the larger constituencies we're accountable to.
In short, we should seek to steadfastly protect the viability of our organizational vehicles and courageously confront internal challenges in ways that allow us to wage the fights we need to wage.
###
**VIII.**
Unanchored Care
####
Definition
Assuming one's mental, physical, and spiritual health is the responsibility of the organization or collective space. The onus is on the organization to deal with the harm, burnout, or psychological stress one may experience through the work. An organization or movement should prioritize addressing individuals' feelings and healing any harm they encounter. Collective projects, campaigns, and efforts can and should be interrupted in service of this priority.
Additionally, the scope of care a movement space, organization, or group is responsible for is sprawling--potentially addressing all or most personal triggers and traumas experienced in and outside the work.
####
Fallacies
Discerning what is yours to hold and what is the collective's is an essential life skill and fundamental to organizational work, collaboration, and meaningful engagement of others. Organizations generally do not have the specialized skills to provide emotional or spiritual healing. Workplaces can provide a salary, benefits, paid time off, and other resources to help individuals access the support and care they require. Workplaces can also promote a culture of care and encourage individuals to care for themselves. Workplaces and colleagues cannot replace medical professionals, spiritual supports, or other devoted spaces of care.
This is also true for non-professional spaces. Your comrades can provide support, foster a caring environment, or help you out when you're in distress. They cannot heal you or salve long-standing traumas. It is natural for us to turn to those closest when we're in pain. It is an indictment of the larger systems in our society that abundant mental health and healing resources are not available to most of us. There are several groups now filling that void in a culturally competent manner, such as
[Nqttcn.com]()
,
[beam.org]()
,
[fireweedcollective.org]()
,
[generativesomatics.org]()
, and
[sinsinvalid.org]()
.
Emotional intelligence is a capacity an organization can and should embody. But no organization can take on the emotional labor that is squarely in the domain of the individual. This distinction is critical. Additionally, discomfort is part of the human condition and a prerequisite for learning. Violence and oppression are to be avoided but not discomfort. The ability to discern the difference is a form of emotional maturity we should encourage.
###
**IX.**
Disproportionality
####
**Definition**
Being unable to interpret the scale of a problem. For example, discomfort is not only unacceptable but "violent." Any mistake committed by the organization or an individual is an example of failure or corruption.
####
**Fallacies**
Disproportionality can be a byproduct of uneven training on concepts like power and power analysis as well as a misunderstanding of strategy. This tendency ultimately weakens meaning, dulls analysis, and robs us of the ability to acknowledge and process instances of violence and oppression. If everything is "violent," nothing really is. If every slight is "oppression," nothing is.
###
**X.**
Activist Culture
####
Definition
Acting on individual and personal impulses rather than the mandate laid out by one's role or organization. Desire to elevate one's individual brand or cultural cachet as a function of one's work. A desire to make an organization or movement visible in a manner that either disregards or undermines process, protocol, or culture.
####
Fallacies
Although it may be personally fulfilling and individually empowering to do and say the things you desire when you desire, institution- and organization-building requires the discipline to advance a collective strategy. That often means sublimating your impulse or ego for the greater good and leveraging your personal capacities for collective goals. This flies in the face of activist culture.
At its very worst, activism absent the disciplining force of accountability to the whole or a guiding ideology is a dangerous venue for narcissism shrouded in "Left speak." It can become the performance of principle without the headache of accountability.
We all have a role to play if we are to transcend these tendencies. Leaders of institutions -having more positional power- hold responsibility for their own behavior, the stewardship of their organizations, and a broader duty to facilitate movement-wide progress. At the same time, we cannot hold out for saviors in these roles. One leader or even a group of dynamic leaders cannot solve something that is very much "in the water" everywhere. It would be inconsistent for me to diagnose a problem as structural while pointing to solutions that can be executed only by a handful of individuals. We must adopt a more comprehensive understanding of leadership that recognizes that leaders and leadership exist at all levels of our organizations and movements. And importantly, the mass leadership of the working class -while unrealized- is a form of leadership with the potential to mitigate some of the tendencies outlined above, keeping our focus outward and on the main struggle.
All of us -- union stewards, field managers, text bank leaders, cultural workers, political educators, neighborhood block captains, members, donors -- have opportunities to lead and choices to make about our behavior. Concretely, that looks like each of us wrestling with the ways we exhibit some of these destructive tendencies and making corrections. It could also look like a large group of leaders, across a number of organizations and sectors, joining forces to advance a collective shift in our practices.
From Problem to Solution
===========================
What can we learn from our errors and our attempts to correct these errors in service of sustainable solutions? How can we shift from a posture that simply analyzes the problems into one that is working to solve them?
Rather than reacting to myriad symptoms, we must build resilient organizations that can weather internal conflict and external crises. Resilient organizations are structurally sound, ideologically coherent, strategically grounded, and emotionally mature. The dimensions of resilient organizations include:
* **Structural:**
The organizational form, roles, and mission.
*What kind of vehicle are we?*
* **Ideological:**
The organizational vision for the world.
*Where are we going?*
* **Strategic:**
The organizational plan to advance toward this vision.
*How do we get there?*
* **Emotional:**
The organization's expectations of its people and people's expectations of the organization in matters of emotional, physical, and spiritual care and well-being.
*How do we behave on the journey?*
###
Structural
* Managers should support and recognize unionization efforts inside movement organizations as a reflection of our values. There is great potential for internal staff unions to strengthen our workplaces, including by inoculating against or mitigating the tendencies outlined here. Organizing and contract negotiations can sharpen the skills of--and connections among--non-managerial staff as well as deepen management's awareness of problems and the organization's overall health. Collective bargaining agreements can increase clarity, promote equity, foster accountability, and provide a common language across an organization. And, most importantly, healthy labor/management relations can bridge gaps and serve as an ongoing resource for managers and unit members to tend to collective goals. No process, including unionization, can be a panacea to all our institutional woes. When done with enthusiastic, upfront support from managers and a bargaining unit committed to the organizational mission and vehicle, unionization can mitigate glass house/small war/anti-leadership tendencies rather than feed them.
* Leaders should be clearer and more transparent about where hierarchies exist, why they exist, and where and how decision making lives. This requires formal, clear, and understandable decision making and leadership structures. This also means up-front validation of those structures in relation to the organizational mission in contexts like onboarding and recruitment. Additionally, people should understand their place in these structures as well as opportunities for their leadership development and advancement.
Various tools exist to help clarify decision making, including
[DARCI]()
,
[MOCHA]()
, and Interaction Institute's
[decision making framework]()
. No one tool is ideal for all contexts. However, having one is critical.
* Organizations should promote a "pro-leadership" culture. Such a culture does not elevate individual leaders or place them beyond reproach. It does define and practice a form of leadership that moves us away from neoliberal individualism toward collective power and accountability. In the context of a grassroots or base-building organization, this looks like rooting leadership in the working-class base. In staffed organizations that are grassroots and community-based, this means ensuring that non-staff leadership is pronounced and real and staff leadership is accountable, clear, and experienced. This also requires rigorous training, practice, and intentional development of a culture that elevates the leadership of working people.
* Hierarchy, commitment to leadership--including leadership development--and other pro-leadership ideas cannot be assumed and are not self-evident. They must complement and be justified by the organization's mission and theory of change.
* Efforts should be made to minimize bureaucratic structures. In staffed organizations, managers should be trained to affirm how and where staff can raise concerns, ask informed questions, experiment, lead, and be creative. In such a culture, seniority is not fetishized for seniority's sake. Instead, there is a matter-of-fact recognition that, with experience, one tends to grow in judgment and has a clearer understanding of what one does not know. This must be supported by the actual organizational culture of leadership development so more senior leaders are tasked with training and supporting less experienced people to execute, learn, and become leaders themselves.
* There should be regular evaluation of decisions and campaigns. Leaders and decision makers should also be regularly evaluated--not just by other leaders and decision makers but also by people who report to them. Their strategies should also be regularly evaluated based on the organizational theory of change.
* In staffed organizations, serious effort should be made to diversify the organization across all dimensions of identity. This is not for the sake of token representation but because true diversity yields the most relevant and community-reflective structures. Take the time to find quality fits for staff roles and ensure that diversity takes place on all levels of the organization.
* If we value experience, emotional maturity, and diversity, we must get serious about staff retention--developing the systems, practices, and culture that create workplaces where people stay and thrive long term.
###
Ideological
* Organizations should be trained and retrained in their own ideological location and destination. Staff should be fluent in the ideological underpinnings of the organization.
* Some re/unlearning and philosophical clarity is necessary. Postmodern philosophies have broad value in helping us perceive and challenge grand narratives and socially constructed hierarchies. However, some postmodernist relativism can collide directly with the entire enterprise of power building, which rests on materialist principles. We seek to understand, deconstruct, and interpret the world only to serve the goal of changing it, not simply to further the production of knowledge. That is arguably the role of the academy and organic intellectuals, not social change agents. Marx says on this point, "...philosophers have only interpreted the world in various ways. The point, however, is to change it." We should take this to heart.
* Continuing political education should be a cultural norm for all. Ideological education should be offered and promoted movement-wide so that there is a common movement vocabulary.
###
Strategic
* Leaders should ensure that the organizational strategy is clear and understood across the board. Invest in training all stakeholders on how the strategy was developed, what hypotheses are operating underneath the strategy, and how to measure the strategy's effectiveness.
* Strategy and theory of change should be the ultimate arbiter of which tactics to employ and demands to make as well as how to assess inevitable compromises in a situation where we have limited power. Develop a practical expression of the organization's strategy and theory of change and work with it regularly in planning and decision-making sessions.
* The organization and its senior leaders should invest serious time in presenting the full and complex strategic landscape to more junior, less experienced, and newer people. There are, of course, times when details are so sensitive that they cannot be shared widely. We should push to make those cases exceptions and, even in these instances, provide a rationale for the secure nature of the information. We should tend toward strategic transparency. This is an opportunity to build strategic trust and sophistication across an organization.
* Organizations should note where they are in their life cycle, and efforts should be made to evaluate this from time to time. This will validate a commitment to affirm, strengthen, and grow the political project. Also, if the organization has satisfied its objectives or is rendered unable to satisfy them, it can set the stage for a careful and responsible wind down.
###
Emotional
* See as a center of your work the establishment and re-establishment of connection, meaning, and belonging.
* Make the celebration of the individual and collective contributions of your people a rigorous practice. Help your teams cultivate a practice of finding the lessons, the steps of success, the moments of laughter and camaraderie, the times that are special. Build a culture of celebration.
* The organization should always endeavor to have the best possible impact on the emotional well-being of its people. Toward that end, the organization should be clear and consistent about its responsibilities in relation to the emotional, mental, and general well-being of the people in its orbit. This requires the organization to generate clear boundaries.
* While it's not possible or advisable for an organization to protect its people from discomfort, unnecessary discomfort should be avoided where possible through clarity around roles, accessible avenues of redress for grievances, and encouraging and providing support for skills like effectively engaging in conflict with others.
* Experience matters. In a staffed and non-staffed organization, invest in and take the time to recruit more experienced and emotionally mature people. Non-staffed movement orgs should seek out members with longer memories and the emotional elasticity to resolve conflict, engage differences to bring a collective together, and elevate the importance of protecting the political vehicle.
* Less experienced leaders or staff should have clarity as to where they are expected to collaborate, contribute, follow, learn, or lead.
* Less experienced leaders or staff should be developed emotionally, strategically, and ideologically. Spend the resources to coach, support, onboard, and train them. They are a special responsibility.
* Don't recruit too many less experienced people at once. Less experienced people need more time, mentorship, and training to excel. Effectively providing such support requires much more time and labor than we typically allow.
* Hire slowly, always. Unintentional scale is an enemy to solid culture. A healthy organizational culture should be prioritized over sheer scale. Take time in establishing and reestablishing culture as you hire.
* In staffed organizations, emotional maturity should be evaluated before hiring, elevated as a key value during onboarding, and reinforced through regular performance evaluations. In non-staffed spaces, emotional maturity must be considered when giving people roles and elevating people in leadership and responsibility.
* There is a training gap for managers and staff in identifying and dealing with trauma--we must confront this and build up both internal and movement-wide resources to support our folks working to change a traumatizing world.
* Resist artifacts from professional culture that either denigrate joy, celebration, pleasure, and expression or put them in a box. Free them from those boxes and allow them to flow throughout your organization. This means organizing with all five senses. Food, visual art, music, movement, and culture should be expressed in all corners of the organization to humanize our practice and develop more emotionally dynamic spaces. Normalize the idea that rigor, seriousness, and excellent work should coexist with fun and joy.
A Vision of Joy, Power, and Victory
======================================
In this paper, I have laid out a diagnosis of our current predicament and sketched out some ways forward. Building the movement of our dreams can at times feel like a utopian fantasy. Our myriad problems and conflicts can make that project feel like an impossible puzzle to piece together. This framework and my recommendations are designed so that our freedom dream can begin to translate into a practical and urgent charge of our day.
I believe our people deserve mass movements that exude joy, build power, and secure critical victories for the masses of working people. Such movements would be irresistible. People associated with these change projects would themselves exhibit liberatory values, including the practice of radical compassion and humility. They would work from a grounded understanding of power. Leaders would invite accountability, act with rigor, and speak with clarity. Problems and contradictions would be met with curiosity instead of judgment and finger pointing. Harm would be addressed with seriousness and an eye toward reparation, remediation, and healing. And we would build power with relish and let our successes and failures breed innovation.
We are closer than we think to such a reality. We must go through a humbling but necessary period of change to achieve it. We must learn how to synthesize lessons from the past and observations in the present. That means sitting in an awkward both/and place. We must call out fallacies that weaken us, even when it's hard and we face criticism for it. And we must meet our problems with grounded solutions that are drawn from a sober assessment of the larger time, place, and conditions we find ourselves in. None of this, of course, will be easy. In fact, much of it will cause great discomfort. However, on the other side of the uncomfortable journey is an abundant, playful, and powerful home for our freedom dreams. Will we choose it?
---
---
Convergence
*is pleased to be co-publishing this article with*
[Nonprofit Quarterly]()
*and*
[The Forge]()
.
*We're sharing it across our platforms as a small step towards the collaboration the movement needs to build in these challenging times.*
Recommended
-------------
[![Brandon Johnson campaigning for mayor of Chicago]()]( "Emma Tai and Jackson Potter: It's Movements vs. MAGA in Chicago")
####
Tagged
[Local Power Building]()
[Chicago]()
###
[Emma Tai and Jackson Potter: It's Movements vs. MAGA in Chicago]()
By
[Emma Tai]()
and
[Jackson Potter]()
[![MFT 59 on strike March 2022. African American man with bullhorn, multi-racial crowd, signs.]()]( "A Year After Its Big Strike, MFT 59 Stays 'Steady and Ready'")
####
Tagged
[Labor Organizing]()
[Public Education]()
###
[A Year After Its Big Strike, MFT 59 Stays 'Steady and Ready']()
By
[Ma-Riah Roberson-Moody]()
,
[Marcia Howard]()
,
[Nat Anderson-Lippert]()
,
and
[Stephanie Luce]()
[![Stand Up KC rally]()]( "People-Side Economics: Explaining the Rules of the Economy Game")
###
[People-Side Economics: Explaining the Rules of the Economy Game]()
By
[Heather McGhee]()
and
[Stephanie Luce]()
####
Tagged
[Organizing Practice]()
[Top 10 of 2022]()
####
Referenced Organizations
[Working Families Party]()
####
About the Author
![head shot of Maurice Mitchell, Working Families Party]()
[Maurice Mitchell]()
[Maurice Mitchell]()
Maurice Mitchell is a nationally-recognized social movement strategist and organizer for racial, social, and economic justice. Raised by Caribbean working-class parents in NY, Maurice began organizing as a teenager. After graduating from Howard University, he went on to work as an organizer for the Long Island Progressive Coalition, downstate organizing director for Citizen Action of NY, and Director of the NY State Civic Engagement Table. After Mike Brown was killed by police in Missouri, Maurice relocated to Ferguson to support work on the ground. Seeing the need for an anchor organization to provide strategic support and guidance to Movement for Black Lives activists, Maurice co-founded and managed Blackbird. In 2015, he helped organize the Movement for Black Lives convention in Cleveland. In 2018, Maurice took the helm of
[Working Families Party]()
as National Director where he is applying his passion and experience to make the WFP the political home for a multi-racial working class movement.
![Convergence "C" logo with text -- black]()
Convergence is a magazine for radical insights. We produce articles, videos, and podcasts to sharpen our collective practice, lift up stories about organizing, and engage in strategic debate -- all with the goal of winning multi-racial democracy and a radically democratic economy.
####
Sections
* [Latest]()
* [Podcasts]()
* [Videos]()
* [Donate Now]()
* [Buy the Book]()
####
Convergence
* [About]()
* [Contact]()
* [Submissions]()
* [Subscribe]()
Copyleft 2023 Convergence
* [xml version="1.0" encoding="utf-8"?
Find us on Facebook]( "Find us on Facebook")
* [xml version="1.0" encoding="utf-8"?
Find us on Instagram]( "Find us on Instagram")
* [xml version="1.0" encoding="utf-8"?
Find us on Twitter]( "Find us on Twitter")
* [xml version="1.0" encoding="utf-8"?
Find us on Youtube]( "Find us on Youtube")
Support Convergence
---------------------
x