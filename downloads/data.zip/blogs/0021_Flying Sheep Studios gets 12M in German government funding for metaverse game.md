Flying Sheep Studios gets $1.2M in German government funding for metaverse game | VentureBeat
[Skip to main content](#primary)
[Events]()
[Video](/video/)
[Special Issues](/gamesbeat-special-issues/)
[Jobs]()
[Subscribe]()
[VentureBeat Homepage](/)
* [Game Development](/category/game-development/)
+ [View All](/category/game-development/)
+ [Programming](/tag/programming/)
+ [OS and Hosting Platforms](/tag/os-hosting-platforms/)* [Metaverse](/category/metaverse/)
+ [View All](/category/metaverse/)
+ [Virtual Environments and Technologies](/tag/virtual-environments-technologies/)
+ [VR Headsets and Gadgets](/tag/vr-headsets-gadgets/)
+ [Virtual Reality Games](/tag/virtual-reality-games/)* [Gaming Hardware](/category/gaming-hardware/)
+ [View All](/category/gaming-hardware/)
+ [Chipsets & Processing Units](/tag/chipsets-processing-units/)
+ [Headsets & Controllers](/tag/headsets-controllers/)
+ [Gaming PCs and Displays](/tag/gaming-pcs-displays/)
+ [Consoles](/tag/consoles/)* [Gaming Business](/category/gaming-business/)
+ [View All](/category/gaming-business/)
+ [Game Publishing](/tag/game-publishing/)
+ [Game Monetization](/tag/game-monetization/)
+ [Mergers and Acquisitions](/tag/mergers-acquisitions/)
+ [Games Releases and Special Events](/tag/game-releases-special-events/)
+ [Gaming Workplace](/tag/gaming-workplace/)* [Latest Games & Reviews](/category/latest-games-reviews/)
+ [View All](/category/latest-games-reviews/)
+ [PC/Console Games](/tag/console-gaming/)
+ [Mobile Games](/tag/mobile-games/)
+ [Gaming Events](/tag/gaming-events/)
+ [Game Culture](/tag/game-culture/)
[Subscribe]()
[Events]()
[Video](/video/)
[Special Issues](/gamesbeat-special-issues/)
[Jobs]()
[VentureBeat Homepage](/)
Flying Sheep Studios gets $1.2M in German government funding for metaverse game
=================================================================================
[Dean Takahashi]( "Posts by Dean Takahashi")
[@deantak]()
March 19, 2023 11:01 PM
* [Share on Facebook](//www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fventurebeat.com%2Fgames%2Fflying-sheep-studios-gets-german-government-funding-for-metaverse-game%2F&t=Flying%20Sheep%20Studios%20gets%20%241.2M%20in%20German%20government%20funding%20for%20metaverse%20game)
* [Share on Twitter](//twitter.com/intent/tweet?text=Flying%20Sheep%20Studios%20gets%20%241.2M%20in%20German%20government%20funding%20for%20metaverse%20game&url=https%3A%2F%2Fventurebeat.com%2Fgames%2Fflying-sheep-studios-gets-german-government-funding-for-metaverse-game%2F&via=VentureBeat&related=VentureBeat,GamesBeat)
* [Share on LinkedIn]()
![Flying Sheep Studios has funding from the German government for Star Life.]()
Flying Sheep Studios has funding from the German government for Star Life.
*Image Credit: Flying Sheep Studios*
*Missed the GamesBeat Summit excitement? Don't worry! Tune in now to catch all of the live and virtual sessions
[here.]()*
---
[Flying Sheep Studios]()
said its Star Life title, a social massively multiplayer online (MMO) game targeted at the metaverse, has raised $1.2 million in funding from the German government.
The game is focused on cooperation, and community-driven experiences that will prioritize socializing, diversity and being the party as well as being part of the metaverse, eventually hosting events and concerts for players.
Star Life, a subsidiary of Australia's iCandy Interactive, is being developed with web-based HTML5 technology that will make its metaverse highly accessible.
Flying Sheep Studios said it is "excited to bring Star Life to players worldwide and is looking forward to being a part of the growing metaverse."
The game's funding cam from the German Federal Ministry for Economic Affairs and Climate Action. Star Life will be a highly accessible metaverse game, playable from any browser on any device. For the development of this groundbreaking project, Flying Sheep has hired additional talent, including four industry veterans.
iCandy Interactive has an international footprint of having other video games studios across Asia (Singapore, Malaysia, Thailand, Indonesia) and Flying Sheep Studios is its first major investment made in Europe.
Players can start entering the Star Life metaverse with just one click via a web browser on both desktop and mobile devices. The game also prioritizes diversity, offering players various options for character creation, shopping, and community-driven events, such as concerts and exhibitions.
In addition, Star Life will incorporate optional blockchain-enabled items, or non-fungible tokens (NFTs), giving players more ownership and agency over their virtual belongings. These belongings can be transferred and used on different platforms, making the process streamlined and convenient. Star Life will be a free-to-play game available to everyone.
"We are grateful to the German Federal Ministry for Economic Affairs and Climate Action for their support and trust in our project. This funding demonstrates the federal budget for video games working as intended, fostering the development of cutting-edge technical know-how 'made in Germany' and creating and securing jobs," said Thomas Rossig, managing director of Flying Sheep Studios, in a statement.
Flying Sheep has also hired additional talent, including four industry veterans: Renke Bahlmann, lead game designer; Frank Reitberger, lead 3D developer; Daniel Schemann, head of backend development; and Nina Kiel, head of diversity and inclusion.
Since the company's founding in 2014 in Cologne, Germany, Flying Sheep Studios has delivered over 200 games on time, quality and budget to satisfied clients, often working with brands such as Lego, Barbie and DreamWorks.
iCandy Group is supported by strategic shareholders, including Animoca Brands, Fatfish Group, Baidu, Singtel, SK Square, AIS and IncubateFund, as well as several Australian and international funds.
**GamesBeat's creed**
when covering the game industry is "where passion meets business." What does this mean? We want to tell you how the news matters to you -- not just as a decision-maker at a game studio, but also as a fan of games. Whether you read our articles, listen to our podcasts, or watch our videos, GamesBeat will help you learn about the industry and enjoy engaging with it.
[Discover our Briefings.]()
Join the GamesBeat community!
-------------------------------
Enjoy access to special events, private newsletters and more.
[Join here]()
* [Games
Beat](/category/games/)
* [Follow us on Facebook]()
* [Follow us on Twitter]()
* [Follow us on LinkedIn]()
* [Follow us on RSS]()
* [Press Releases](/tag/business-sponsored-company-news/)
* [Contact Us]()
* [Advertise](/advertise/)
* [Share a News Tip](/contact/)
* [Contribute to DataDecisionMakers](/contribute-to-datadecisionmakers/)
* [Careers]()
* [Privacy Policy](/privacy-policy/)
* [Terms of Service](/terms-of-service/)
* Do Not Sell My Personal Information
©️ 2023
[VentureBeat]()
. All rights reserved.
![Quantcast](//pixel.quantserve.com/pixel/p-UkS7f9ZMSZ6hP.gif)