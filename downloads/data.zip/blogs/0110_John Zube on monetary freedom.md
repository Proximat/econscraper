Editorial Works of John Zube | Reinventing Money
[Reinventing Money]( "Reinventing Money")
Demystifying Money and Liberating Exchange
[Skip to content](#content "Skip to content")
* [Welcome]()
* [Sites]()
* [Library]()
* [My Presentations]()
* [Case Studies]()
* [Research Links]()
* [About]()
[![]()]()
Editorial Works of John Zube
==============================
[A Monetary Freedom Manifesto]()
Revised December 22, 2003 [Emphasis added by Thomas H. Greco, Jr.]
[Peace Plan #9]()
Introducing the "German School" of money and banking and its major proponents from the 1930's, some of whom he knew personally
[Peace Plan #11]()
In this article, John Zube shares some of his extensive insights on issues raised by the von Beckerath articles. The main points covered include Beckerath's proposal for compulsory participation in an insurance plan; the distinction between using gold as a means of payment and using it as merely a standard of value; the effect of monetary freedom on prices
###
Share this:
* [Twitter]( "Click to share on Twitter")
* [Facebook]( "Click to share on Facebook")
*
###
Like this:
Like
Loading...
###
Leave a Reply
[Cancel reply](/zube/#respond)
Enter your comment here...
Fill in your details below or click an icon to log in:
*
*
*
[![Gravatar]()]()
Email
(required)
(Address never made public)
Name
(required)
Website
![WordPress.com Logo]()
You are commenting using your WordPress.com account.
(
[Log Out](javascript:HighlanderComments.doExternalLogout( 'wordpress' );)
/
[Change](#)
)
![Facebook photo]()
You are commenting using your Facebook account.
(
[Log Out](javascript:HighlanderComments.doExternalLogout( 'facebook' );)
/
[Change](#)
)
[Cancel](javascript:HighlanderComments.cancelExternalWindow();)
Connecting to %s
Notify me of new comments via email.
Notify me of new posts via email.
D
* Search for:
* ###
Categories
Categories
Select Category
Uncategorized
* ###
Follow this site via Email
Enter your email address to follow this site and receive notifications of new posts by email.
Email Address:
Follow
Join 390 other subscribers
[Blog at WordPress.com.]()
* + [![]()
Reinventing Money]()
+ [Customize]()
+ [Sign up]()
+ [Log in]()
+ [Copy shortlink]()
+ [Report this content]()
+ [Manage subscriptions]()
%d
bloggers like this:
![]()