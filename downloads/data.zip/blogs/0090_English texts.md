Documents of Ulrich von Beckerath | Reinventing Money
[Reinventing Money]( "Reinventing Money")
Demystifying Money and Liberating Exchange
[Skip to content](#content "Skip to content")
* [Welcome]()
* [Sites]()
* [Library]()
* [My Presentations]()
* [Case Studies]()
* [Research Links]()
* [About]()
[![]()]()
Documents of Ulrich von Beckerath
===================================
[COMPENSATION MONEY AND PUBLIC INSURANCE]()
The possibility of developing insurance facilities in Asia, in colonies, and new countries, through applying the Milhaud System: Together with some reflections on this system.
[THE PRACTICAL REALIZATION OF THE MILHAUD PROPOSALS]()
An essay on the theory and practice of the monetary freedom required to make the market really free.
[MUST FULL EMPLOYMENT COST MONEY?]()
The Financing of Public Works Without Recourse to the Money Market. According to Milhaud's Proposals; With Some Remarks on the Latter
###
**Correspondence of Ulrich von Beckerath**
[COMMENT ON ZANDER'S RAILWAY MONEY PROPOSAL]()
This is a letter from Ulrich von Beckerath to Dr. E. Foerster containing extensive comments on railway money.
[INSTEAD OF A MAGAZINE - Part 1]()
Correspondence Between ULRICH von BECKERATH () and HENRY MEULEN ()
[INSTEAD OF A MAGAZINE - Part 2]()
Correspondence Between ULRICH von BECKERATH () and HENRY MEULEN ()
[INSTEAD OF A MAGAZINE - Part 3]()
Correspondence Between ULRICH von BECKERATH () and HENRY MEULEN ()
[INSTEAD OF A MAGAZINE - Part 4]()
Correspondence Between ULRICH von BECKERATH () and HENRY MEULEN ()
[INSTEAD OF A MAGAZINE - Part 5]()
Correspondence Between ULRICH von BECKERATH () and HENRY MEULEN ()
[INSTEAD OF A MAGAZINE - Part 6]()
Correspondence Between ULRICH von BECKERATH () and HENRY MEULEN ()
###
Share this:
* [Twitter]( "Click to share on Twitter")
* [Facebook]( "Click to share on Facebook")
*
###
Like this:
Like
Loading...
###
Leave a Reply
[Cancel reply](/documents-of-ulrich-von-beckerath/#respond)
Enter your comment here...
Fill in your details below or click an icon to log in:
*
*
*
[![Gravatar]()]()
Email
(required)
(Address never made public)
Name
(required)
Website
![WordPress.com Logo]()
You are commenting using your WordPress.com account.
(
[Log Out](javascript:HighlanderComments.doExternalLogout( 'wordpress' );)
/
[Change](#)
)
![Facebook photo]()
You are commenting using your Facebook account.
(
[Log Out](javascript:HighlanderComments.doExternalLogout( 'facebook' );)
/
[Change](#)
)
[Cancel](javascript:HighlanderComments.cancelExternalWindow();)
Connecting to %s
Notify me of new comments via email.
Notify me of new posts via email.
D
* Search for:
* ###
Categories
Categories
Select Category
Uncategorized
* ###
Follow this site via Email
Enter your email address to follow this site and receive notifications of new posts by email.
Email Address:
Follow
Join 390 other subscribers
[Blog at WordPress.com.]()
* + [![]()
Reinventing Money]()
+ [Customize]()
+ [Sign up]()
+ [Log in]()
+ [Copy shortlink]()
+ [Report this content]()
+ [Manage subscriptions]()
%d
bloggers like this:
![]()