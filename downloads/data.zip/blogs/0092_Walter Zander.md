The papers of Dr Walter Zander | Reinventing Money
[Reinventing Money]( "Reinventing Money")
Demystifying Money and Liberating Exchange
[Skip to content](#content "Skip to content")
* [Welcome]()
* [Sites]()
* [Library]()
* [My Presentations]()
* [Case Studies]()
* [Research Links]()
* [About]()
[![]()]()
The papers of Dr Walter Zander
================================
[THE WALTER ZANDER WEBSITE]()
*The purpose of the Walter Zander website is to make available the writings of Walter Zander, who was born in Germany in 1898 and who died in London in 1993 at the age of 94.*
[A Way Out of the Monetary Chaos]()
by Dr. Walter Zander - Introduction by John Zube
[Railway Money and Unemployment and Further Remarks Concerning Railway Money with Special Reference to the Position of the American Railways]()
by Dr. Walter Zander
[Eisenbahngeld und Arbeitslosigkeit]()
(Original German language version).
[A Brief Letter to Henry Meulen]()
from Walter Zander 10 July 1952.
###
Share this:
* [Twitter]( "Click to share on Twitter")
* [Facebook]( "Click to share on Facebook")
*
###
Like this:
Like
Loading...
###
Leave a Reply
[Cancel reply](/the-papers-of-dr-walter-zander/#respond)
Enter your comment here...
Fill in your details below or click an icon to log in:
*
*
*
[![Gravatar]()]()
Email
(required)
(Address never made public)
Name
(required)
Website
![WordPress.com Logo]()
You are commenting using your WordPress.com account.
(
[Log Out](javascript:HighlanderComments.doExternalLogout( 'wordpress' );)
/
[Change](#)
)
![Facebook photo]()
You are commenting using your Facebook account.
(
[Log Out](javascript:HighlanderComments.doExternalLogout( 'facebook' );)
/
[Change](#)
)
[Cancel](javascript:HighlanderComments.cancelExternalWindow();)
Connecting to %s
Notify me of new comments via email.
Notify me of new posts via email.
D
* Search for:
* ###
Categories
Categories
Select Category
Uncategorized
* ###
Follow this site via Email
Enter your email address to follow this site and receive notifications of new posts by email.
Email Address:
Follow
Join 390 other subscribers
[Blog at WordPress.com.]()
* + [![]()
Reinventing Money]()
+ [Customize]()
+ [Sign up]()
+ [Log in]()
+ [Copy shortlink]()
+ [Report this content]()
+ [Manage subscriptions]()
%d
bloggers like this:
![]()