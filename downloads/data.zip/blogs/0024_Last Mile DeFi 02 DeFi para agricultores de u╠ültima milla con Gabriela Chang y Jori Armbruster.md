Last Mile DeFi 02: DeFi para agricultores de ultima milla con Ga... -- Marcus
[![0x50b6a381993834C623b2Bded6825824C936E48bB]()
Marcus
marcus
.
mirror.xyz]()
Subscribe
Subscribe
![](data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7)
![]()
Last Mile DeFi 02: DeFi para agricultores de ultima milla con Gabriela Chang y Jori Armbruster
![Marcus]()
[Marcus]()
[0x50b6]()
March 23rd, 2023
Mint
!Hola amigas y amigos! Este es el segundo episodio de Last Mile DeFi. En este episodio del podcast, tuve el placer de hablar con
[Gabriela Chang]()
y
[Jori Armbruster]()
del equipo de
[Ethic Hub](http://)
, donde discutimos el potencial de DeFi en Latino America, la importancia de regenerarse a uno mismo, y que oportunidades hay para el espacio de DeFi al apoyar comunidades marginadas como con las que trabaja Ethic Hub:
Tambien encontraras el podcast en tus plataformas de contenido preferidas:
[Lens]()
|
[Spotify]()
|
[Apple]()
|
[YouTube]()
|
[Google]()
|
[Simple Cast]()
Durante este podcast, Jori y Gabriela analizaron los desafios que enfrentan los pequenos agricultores en Mexico para obtener prestamos y microfinanciamiento debido a la falta de infraestructura financiera en la region. Para abordar este problema, Ethic Hub ha desarrollado un sistema innovador en el que cualquier persona de todo el mundo puede prestar dinero a colectivos de agricultores seleccionados a traves de circulos de confianza utilizando criptomonedas. Actualmente, Ethic Hub opera en varios paises de Latinoamerica, incluyendo Mexico, Brasil, Honduras, Colombia, Ecuador y Peru.
La conversacion tambien se centro en el concepto de ser un emprendedor en el mundo regenerativo, conocido como "regen". Jori y Gabriela enfatizaron la importancia de la transformacion personal y discutieron las implicaciones del capitalismo y la revolucion tecnologica, especialmente en relacion con la tecnologia blockchain. Lo mas destacado de la conversacion fue la perspectiva de que el cambio comienza dentro de uno mismo y que se necesita una vision mas amplia para lograr un impacto real.
Ethic Hub es un excelente ejemplo de innovacion en el mundo de la tecnologia blockchain. Al traer el valor del mundo real al mundo de las finanzas descentralizadas, estan desempenando un papel crucial en el desarrollo de DeFi. Esta conversacion ofrece una perspectiva valiosa para aquellos interesados en la innovacion y muestra la importancia de pensar mas alla de los limites para lograr un impacto real.
Para mantenerte actualizado con los ultimos hallazgos, tambien puedes seguirme en
[Twitter]()
y
[Lens]()
. Publicare actualizaciones sobre la investigacion asi que asegurate de unirte a nosotros. !Tambien puedes unirte a nuestro canal de
[Telegram]()
!
Por ultimo, gracias por sus comentarios sobre la version 1 del informe que publique recientemente. Todavia hay tiempo para revisar la version 1 (la sesion de revision abierta cerrara el 31 de marzo, despues de lo cual publicare la version 2 en abril), asi que si aun no lo has leido y revisado, lo recomiendo encarecidamente:
Esta investigacion y podcast se producen con el apoyo de:
**Fellowship de la Ethereum Foundation:**
el programa de
[Fellowship]()
es un foro para lideres que estan impulsados por aprovechar Ethereum como un bien publico para ayudar a miles de millones de personas a coordinarse y prosperar. El programa de becas tiene como objetivo apoyar a personas apasionadas por identificar barreras para la adopcion masiva y derribar las barreras para que las comunidades subrepresentadas accedan a la criptografia.
**Fundacion Celo:**
[Celo]()
es la blockchain construida para el mundo real. Negativa en carbono, movil primero y compatible con EVM, Celo lidera una prospera nueva economia digital para todos. Construyamos juntos y prosperemos.
Subscribe to
Marcus
Receive new entries directly to your inbox.
Subscribe
Subscribe
Mint this entry as an NFT to add it to your collection.
Mint
Verification
This entry has been permanently stored onchain and signed by its creator.
[Arweave Transaction
MkvCkvTx-qeUdwV...sSjjMUmnKyH9xGE]()
[Author Address
0x50b6a38199383...825824C936E48bB]()
Content Digest
x3XkGW5SoqpispP...LTA8eOMPXeIsRpA
More from
Marcus
[View All]()
[###
skeleton
Skeleton](/_sites/[slug]/null/undefined)
[###
skeleton
Skeleton](/_sites/[slug]/null/undefined)
[###
skeleton
Skeleton](/_sites/[slug]/null/undefined)