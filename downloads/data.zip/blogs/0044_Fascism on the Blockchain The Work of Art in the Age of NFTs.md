Jonathan Beller: NFT Does Not Stand for Non-Fascist Token, but It Should - CoinDesk
* + [Crypto Prices](/data/)
+ [CoinDesk Market Index](/indices/cmi/)
+ [TV & Videos](/tv/)
+ [Newsletters](/newsletters/)
+ [Podcasts](/podcasts/)
+ [Consensus Magazine](/consensus-magazine/)
+ [Learn](/learn/)
+ [Bitcoin Calculator](/calculator/)
+ [Consensus]()
+ [Webinars](/webinars/)
+ [Indices](/indices)
+ [About](/about/)
+ [Markets](/markets/)
+ [Finance](/business/)
+ [Technology](/tech/)
+ [Web3](/web3/)
+ [Policy](/policy/)
+ [CoinDesk Studios](/coindeskstudios)
+ [Sponsored Content](/sponsored-content/)
Upcoming event
[![Atmosphere (Shutterstock/CoinDesk)]():format(jpg)/cloudfront-us-east-1.images.arcpublishing.com/coindesk/BZH5EYHWZ5GA5CXLVF7POY567Q.jpg)
Join the Final Consensus 2-for-1 Sale!]()
* [TV & Videos](/tv/)
TV & Videos
+ [First Mover](/tv/first-mover/)
+ [The Hash](/tv/the-hash/)
+ [All About Bitcoin](/tv/all-about-bitcoin/)
+ [Money Reimagined](/tv/money-reimagined/)
+ [Community Crypto](/tv/community-crypto/)
+ [View all shows](/tv/)
Watch On
+ ![Twitter]()
Twitter
+ ![Facebook]()
Facebook
* [Newsletters](/newsletters/)
Sign up for our newsletters
[See All Newsletters](/newsletters/)
![UncheckedCheckbox]()
[The Airdrop]()
Your weekly wrap of Web3 news and trends.
![UncheckedCheckbox]()
[First Mover]()
The latest moves in crypto markets, in context.
![UncheckedCheckbox]()
[The Node]()
The biggest crypto news and ideas of the day.
![UncheckedCheckbox]()
[State of Crypto]()
Probing the intersection of crypto and government.
![UncheckedCheckbox]()
[Crypto Investing Course]()
Be a smarter, safer investor in eight weeks.
![UncheckedCheckbox]()
[The Protocol]()
Exploring the tech behind crypto.
![UncheckedCheckbox]()
[Crypto Long & Short]()
News and analysis for the professional investor.
![UncheckedCheckbox]()
[Crypto for Advisors]()
What financial advisors need to know about crypto.
![UncheckedCheckbox]()
[Money Reimagined]()
The transformation of value in the digital age.
Enter your Email
Subscribe
By signing up, you will receive emails about CoinDesk products and you agree to our
[terms
&
conditions](/terms/)
and
[privacy policy](/privacy/)
.
* [Podcasts](/podcasts/)
Podcasts
+ [CoinDesk Podcast Network](/podcasts/coindesk-podcast-network/)
+ [The Hash](/podcasts/the-hash/)
+ [Markets Daily](/podcasts/markets-daily/)
+ [Money Reimagined](/podcasts/coindesks-money-reimagined/)
+ [The Breakdown, With NLW](/podcasts/the-breakdown-with-nlw/)
+ [Carpe Consensus](/podcasts/carpe-consensus/)
+ [Crypto Crooks](/podcasts/crypto-crooks/)
+ [Women Who Web3](/podcasts/women-who-web3/)
+ [Gen C](/podcasts/generation-c/)
[![Coindesk Logo]()](/)
* ![SearchIconBlack]()
* [Consensus]()
Consensus
+ [Go to Consensus 2024 Site]()
+ [Consensus 2023 Videos]()
+ [Consensus 2022 Videos]()
* [Indices](/indices)
Indices
+ [Bitcoin Price Index (XBX)](/indices/xbx/)
+ [Ether Price Index (ETX)](/indices/etx/)
+ [Basic Attention Token Price Index (BTX)](/indices/btx/)
+ [Bitcoin Cash Price Index (BCX)](/indices/bcx/)
+ [Cardano Price Index (ADX)](/indices/adx/)
---
* [Crypto Prices](/data/)
* [CoinDesk Market Index](/indices/cmi/)
---
* [TV & Videos](/tv/)
* [Newsletters](/newsletters/)
* [Podcasts](/podcasts/)
* [Consensus Magazine](/consensus-magazine/)
* [Learn](/learn/)
* [Bitcoin Calculator](/calculator/)
* [Consensus]()
* [Webinars](/webinars/)
* [Indices](/indices)
* [About](/about/)
---
* [Markets](/markets/)
* [Finance](/business/)
* [Technology](/tech/)
* [Web3](/web3/)
* [Policy](/policy/)
* [CoinDesk Studios](/coindeskstudios)
---
* Sponsored Content
Chevrone Right Icon
---
Upcoming event
[![Atmosphere (Shutterstock/CoinDesk)]():format(jpg)/cloudfront-us-east-1.images.arcpublishing.com/coindesk/BZH5EYHWZ5GA5CXLVF7POY567Q.jpg)]()
[Join the Final Consensus 2-for-1 Sale!]()
* [Markets](/markets/)
Markets
+ [On-Chain Data](/tag/on-chain-data/)
+ [Token Governance](/tag/token-governance/)
+ [Bitcoin](/tag/bitcoin/)
+ [Ether](/tag/ether/)
+ [First Mover](/tag/first-mover/)
* [Finance](/business/)
Finance
+ [FTX](/tag/ftx/)
+ [SBF](/tag/sbf/)
+ [NFTs](/tag/nfts/)
+ [Coinbase](/tag/coinbase/)
+ [Business](/tag/business/)
* [Policy](/policy/)
Policy
+ [Regulations](/tag/regulations/)
+ [Bankruptcy](/tag/bankruptcy/)
+ [SEC](/tag/sec/)
+ [FTX](/tag/ftx/)
+ [CFTC](/tag/cftc/)
* [Technology](/tech/)
Technology
+ [On-Chain Data](/tag/on-chain-data/)
+ [Token Governance](/tag/token-governance/)
+ [DeFi](/tag/defi/)
+ [Blockchains](/tag/blockchains/)
+ [Hacks](/tag/hacks/)
* [Web3](/web3/)
Web3
+ [Yuga Labs](/tag/yuga-labs/)
+ [NFTs](/tag/nfts/)
+ [Metaverse](/tag/metaverse/)
+ [Dao](/tag/dao/)
+ [Gaming](/tag/gaming/)
* [Learn](/learn/)
Learn
+ [NFTs](/learn/nfts/)
+ [Bitcoin](/learn/bitcoin/)
+ [Ethereum](/learn/ethereum/)
+ [Cryptocurrency](/learn/cryptocurrency/)
+ [Investing](/learn/investing/)
Crash Courses
+ [Bitcoin 101](/learn/crash-courses/bitcoin-101/)
+ [DeFi 101](/learn/crash-courses/defi-101/)
+ [Ethereum 101](/learn/crash-courses/ethereum-101/)
+ [NFT 101](/learn/crash-courses/nft-101/)
+ [Price Data 101](/learn/crash-courses/price-data-101/)
* [Consensus Magazine](/consensus-magazine/)
Consensus Magazine
+ [Crypto Hubs 2023](/consensus-magazine/best-crypto-hubs-2023/)
+ [Consensus @ Consensus](/consensus-magazine/consensus-at-c23/)
+ [Projects to Watch 2023](/consensus-magazine/crypto-projects-to-watch-2023/)
+ [Tax Guide 2023](/consensus-magazine/tax-guide-2023/)
+ [Culture Week](/consensus-magazine/culture-week-2023/)
Most Recent Issue
[![CoinDesk - Unknown]():format(jpg)/cloudfront-us-east-1.images.arcpublishing.com/coindesk/I7UEEYFV2ZHUJLP7HLZWW2WDSQ.png)](/consensus-magazine/mining-week-2023/)
* [Sponsored Content](/sponsored-content/)
Sponsored Content
+ [NEAR](/sponsored-content/hub/Near/)
+ [Gate.US](/sponsored-content/hub/gate.us/)
+ [abra](/sponsored-content/hub/abra/)
+ [Matrixport](/sponsored-content/hub/Matrixport/)
+ [SocialGood](/sponsored-content/hub/SocialGood/)
+ [Tron](/sponsored-content/hub/Tron/)
[Bitcoin
$
29,117.32
-1.40%](/price/bitcoin/)
[Ethereum
$
1,834.96
-1.24%](/price/ethereum/)
[Binance Coin
$
240.58
-2.27%](/price/binance-coin/)
[XRP
$
0.68473878
-1.81%](/price/xrp/)
[Dogecoin
$
0.
-4.04%](/price/dogecoin/)
[Cardano
$
0.29503100
-3.97%](/price/cardano/)
[Solana
$
22.73
-3.77%](/price/solana/)
[Tron
$
0.
-1.81%](/price/tron/)
[Polkadot
$
5.04
-2.40%](/price/polkadot/)
[Polygon
$
0.68012969
-2.47%](/price/polygon/)
[Litecoin
$
86.16
-5.16%](/price/litecoin/)
[Shiba Inu
$
0.
-2.18%](/price/shiba-inu/)
[Wrapped Bitcoin
$
29,122.19
-1.36%](/price/wrapped-bitcoin/)
[Uniswap
$
6.20
-1.89%](/price/uniswap/)
[Bitcoin Cash
$
228.94
-3.46%](/price/bitcoin-cash/)
[Avalanche
$
12.51
-2.20%](/price/avax/)
[Toncoin
$
1.19
-2.14%](/price/toncoin/)
[Chainlink
$
7.30
-4.35%](/price/chainlink/)
[Stellar
$
0.
-4.75%](/price/stellar/)
[UNUS SED LEO
$
3.97
+
0.78%](/price/unus-sed-leo/)
[Binance USD
$
0.99896820
-0.41%](/price/binance-usd/)
[TrueUSD
$
0.99907234
-0.30%](/price/trueusd/)
[Monero
$
159.12
-0.72%](/price/monero/)
[Ethereum Classic
$
18.04
-1.23%](/price/ethereum-classic/)
[Cosmos
$
8.74
-2.22%](/price/cosmos/)
[OKB
$
42.03
-1.15%](/price/okb/)
[Filecoin
$
4.26
-0.14%](/price/filecoin/)
[Internet Computer
$
4.14
-0.68%](/price/internet-computer/)
[Hedera
$
0.
-1.71%](/price/hedera/)
[Lido DAO
$
1.85
-1.87%](/price/load-network/)
[Cronos
$
0.
+
0.16%](/price/cryptocom/)
[Quant
$
104.58
-1.44%](/price/quant/)
[Aptos
$
6.89
-1.36%](/price/aptos/)
[Arbitrum
$
1.13
-1.79%](/price/arb-protocol/)
[VeChain
$
0.
-2.88%](/price/vechain/)
[NEAR Protocol
$
1.40
-0.62%](/price/near-protocol/)
[Optimism
$
1.65
-0.09%](/price/optimism/)
[Maker
$
1,296.40
-1.81%](/price/maker/)
[XDC Network
$
0.
+
10.92%](/price/xdc-network/)
[The Graph
$
0.
-1.83%](/price/the-graph/)
[Aave
$
65.03
+
2.57%](/price/aave/)
[Stacks
$
0.61046050
-0.47%](/price/stacks/)
[Algorand
$
0.
-2.36%](/price/algorand/)
[Immutable X
$
0.75609180
-3.22%](/price/immutable-x/)
[EOS
$
0.72599400
-2.56%](/price/eos/)
[Elrond
$
31.28
-2.25%](/price/elrond/)
[The Sandbox
$
0.41157304
-2.39%](/price/the-sandbox/)
[Synthetix
$
2.48
-3.35%](/price/synthetix/)
[Axie Infinity
$
5.91
-2.65%](/price/axie-infinity/)
[Tezos
$
0.82200000
-2.84%](/price/tezos/)
[Theta
$
0.75799140
-0.76%](/price/theta-network/)
[BitDAO
$
0.50480528
-4.37%](/price/bitdao/)
[USDD
$
0.99575147
-0.19%](/price/usdd/)
[Bitcoin SV
$
36.74
-2.93%](/price/bitcoin-sv/)
[Decentraland
$
0.37235291
-2.26%](/price/decentraland/)
[Injective Protocol
$
7.96
-2.02%](/price/injective-protocol/)
[Fantom
$
0.23794467
-3.70%](/price/fantom/)
[ApeCoin
$
1.78
-2.15%](/price/apecoin/)
[Render Token
$
1.76
-1.64%](/price/render-token/)
[NEO
$
8.58
-2.81%](/price/neo/)
[Flow
$
0.57506952
-1.47%](/price/flow/)
[eCash
$
0.
-2.15%](/price/ecash/)
[Gala
$
0.
-2.46%](/price/gala/)
[Kava.io
$
0.86561189
-0.43%](/price/kava-io/)
[GateToken
$
4.14
+
0.27%](/price/gatetoken/)
[Rocket Pool
$
28.91
-4.68%](/price/rocket-pool/)
[KuCoin Token
$
5.62
-0.78%](/price/kucoin-token/)
[Radix
$
0.
-4.85%](/price/radix/)
[Paxos Dollar
$
0.99632708
-0.42%](/price/paxos-dollar/)
[Chiliz
$
0.
-1.87%](/price/chiliz/)
[Curve DAO Token
$
0.57820066
+
1.22%](/price/curve-dao-token/)
[Klaytn
$
0.
-1.58%](/price/klaytn/)
[IOTA
$
0.
-0.92%](/price/iota/)
[PAX Gold
$
1,925.79
-0.88%](/price/pax-gold/)
[Luna Classic
$
0.
-0.94%](/price/luna-classic/)
[GMX
$
50.09
-2.56%](/price/gmx/)
[Sui
$
0.61259165
-3.47%](/price/sui/)
[BitTorrent
$
0.
-0.91%](/price/bittorrent/)
[Frax Share
$
5.95
+
3.09%](/price/frax-share/)
[Casper
$
0.
-0.30%](/price/casper/)
[Compound
$
62.55
-2.54%](/price/compound/)
[Huobi Token
$
2.68
-0.83%](/price/huobi-token/)
[Mina
$
0.43548269
-1.60%](/price/mina/)
[Trust Wallet Token
$
0.93374662
-1.88%](/price/twt/)
[Bone ShibaSwap
$
1.62
-2.46%](/price/bone-shibaswap/)
[Gemini Dollar
$
1.01
+
0.03%](/price/gemini-dollar/)
[Dash
$
31.83
-1.22%](/price/dash/)
[Nexo
$
0.64430898
-2.27%](/price/nexo/)
[Arweave
$
5.33
-3.61%](/price/arweave/)
[Zilliqa
$
0.
-2.47%](/price/zilliqa/)
[Woo Network
$
0.
-1.45%](/price/woo-network/)
[dYdX
$
1.97
-0.73%](/price/dydx/)
[1inch Network
$
0.31522785
+
0.26%](/price/1inch-network/)
[PancakeSwap
$
1.51
-2.00%](/price/pancakeswap/)
[Basic Attention Token
$
0.20458000
+
1.26%](/price/basic-attention-token/)
[Flare
$
0.
-2.38%](/price/flare/)
[Enjin
$
0.29045104
-1.73%](/price/enjin-coin/)
[Gnosis
$
111.81
-1.94%](/price/gnosis/)
[Osmosis
$
0.47022809
-1.79%](/price/osmosis-2/)
[Qtum
$
2.71
-5.99%](/price/qtum/)
[Mask Network
$
3.44
-2.67%](/price/mask-network/)
[THORChain
$
0.92697910
-2.26%](/price/thorchain/)
[Bitcoin Gold
$
15.85
-6.40%](/price/bitcoin-gold/)
[NEM
$
0.
-0.95%](/price/nem/)
[Loopring
$
0.21167938
-0.89%](/price/loopring/)
[Helium
$
1.81
+
3.03%](/price/hnt/)
[Celo
$
0.48918113
-0.47%](/price/celo/)
[Convex Finance
$
3.09
-4.10%](/price/convex-finance/)
[Ethereum Name Service
$
9.48
-3.47%](/price/ethereum-name-service/)
[Zcash
$
29.58
-1.33%](/price/zcash/)
[BLUR
$
0.29752048
-1.92%](/price/blur/)
[Oasis Network
$
0.
-1.93%](/price/oasis-network/)
[Illuvium
$
40.79
-0.53%](/price/ilv/)
[Astar
$
0.
-4.10%](/price/astar/)
[Holo
$
0.
-2.06%](/price/hot/)
[FLOKI
$
0.
-1.40%](/price/floki/)
[Decred
$
14.30
-0.22%](/price/decred/)
[Ravencoin
$
0.
-2.62%](/price/ravencoin/)
[Fetch.ai
$
0.20399584
-2.64%](/price/fetchai/)
[Yearn Finance
$
6,434.82
-4.08%](/price/yearn-finance/)
[Kusama
$
23.57
-1.09%](/price/kusama/)
[Stepn
$
0.20827754
-2.14%](/price/stepn/)
[Golem
$
0.20875708
+
1.18%](/price/golem/)
[ICON
$
0.21577301
-1.21%](/price/icon/)
[Ankr
$
0.
-1.95%](/price/ankr/)
[Wemix
$
0.62457192
+
0.71%](/price/wemix/)
[Terra 2.0/LUNA
$
0.56743394
-1.59%](/price/terra-20luna/)
[SXP
$
0.33268952
-2.04%](/price/sxp/)
[Waves
$
1.91
-0.67%](/price/waves/)
[Baby Doge Coin
$
0.
-4.00%](/price/babydoge/)
[Audius
$
0.
-2.31%](/price/audius/)
[JasmyCoin
$
0.
-0.99%](/price/jasmycoin/)
[EthereumPoW
$
1.71
-1.79%](/price/ethereum-pow/)
[Balancer
$
4.30
-0.89%](/price/balancer/)
[Aragon
$
4.44
-0.15%](/price/aragon/)
[Siacoin
$
0.
-2.16%](/price/siacoin/)
[IoTeX
$
0.
-2.35%](/price/iotex/)
[Wax
$
0.
-1.16%](/price/wax/)
[Band Protocol
$
1.21
-0.93%](/price/band-protocol/)
[Moonbeam
$
0.22787157
-1.42%](/price/moonbeam/)
[TerraUSD
$
0.
+
3.85%](/price/terrausd/)
[SafePal
$
0.40998406
-3.76%](/price/safepal/)
[Ribbon Finance
$
0.
-0.09%](/price/ribbon-finance/)
[Ocean Protocol
$
0.34337679
-1.44%](/price/ocean-protocol/)
[Amp
$
0.
-4.44%](/price/amp/)
[Harmony
$
0.
-2.24%](/price/one/)
[Kyber Network
$
0.76280717
+
5.90%](/price/kyber-network/)
[Sushiswap
$
0.71489715
-1.13%](/price/sushiswap/)
[Gains Network
$
4.52
+
1.56%](/price/gains-network/)
[Axelar
$
0.39326553
-1.62%](/price/axelar/)
[Polymath Network
$
0.
+
0.70%](/price/polymath-network/)
[Biconomy
$
0.21428979
-2.99%](/price/biconomy/)
[DigiByte
$
0.
-2.08%](/price/digibyte/)
[Horizen
$
9.29
-1.14%](/price/horizen/)
[Skale
$
0.
-2.27%](/price/skale/)
[Lisk
$
0.88465082
+
1.50%](/price/lisk/)
[Core
$
0.83715671
+
1.10%](/price/core/)
[Stargate Finance
$
0.58714247
-0.77%](/price/stargate-finance/)
[UMA Protocol
$
1.60
-0.41%](/price/uma-protocol/)
[Synapse
$
0.59636778
-3.03%](/price/synapse/)
[Livepeer
$
3.96
-1.37%](/price/livepeer/)
[Joe
$
0.30869520
-2.57%](/price/joe/)
[Cartesi
$
0.
-2.30%](/price/cartesi/)
[OriginTrail
$
0.26560024
-3.29%](/price/origin-trail/)
[Liquity
$
1.05
-0.96%](/price/liquity/)
[PlayDapp
$
0.
-2.23%](/price/playdapp/)
[Nervos Network
$
0.
-1.54%](/price/nervos-network/)
[Nano
$
0.66498918
-2.14%](/price/nano/)
[Alchemy Pay
$
0.
-1.64%](/price/alchemy-pay/)
[iExec RLC
$
1.19
-1.32%](/price/iexec-rlc/)
[Merit Circle
$
0.
-2.73%](/price/meritcircle/)
[Dogelon Mars
$
0.
-1.82%](/price/elon/)
[API3
$
0.96548614
-2.14%](/price/api3/)
[Numeraire
$
13.27
-2.45%](/price/numeraire/)
[Steem
$
0.
-1.30%](/price/steem/)
[Verge
$
0.
-1.85%](/price/verge/)
[Celer Network
$
0.
-1.98%](/price/celer-network/)
[NuCypher
$
0.
-0.16%](/price/nucypher/)
[OMG Network
$
0.55314824
-1.07%](/price/omgnetwork/)
[Radicle
$
1.55
-1.85%](/price/radicle/)
[Syscoin
$
0.
-2.20%](/price/syscoin/)
[Coin98
$
0.
-1.37%](/price/coin98/)
[Vulcan Forged PYR
$
3.06
-2.69%](/price/vulcan-forged-pyr/)
[My Neighbor Alice
$
0.93770345
-2.07%](/price/my-neighbor-alice/)
[Celsius
$
0.
-1.22%](/price/celsius/)
[Dent
$
0.
-0.40%](/price/dent/)
[SPACE ID
$
0.24558245
-2.66%](/price/space-id/)
[Stormx
$
0.
-3.36%](/price/stormx/)
[Powerledger
$
0.
-2.25%](/price/powerledger/)
[Civic
$
0.
-0.80%](/price/civic/)
[Braintrust
$
0.27345723
-1.00%](/price/braintrust/)
[Marlin
$
0.
-1.96%](/price/marlin/)
[MetisDAO
$
15.27
-1.66%](/price/metisdao/)
[Secret
$
0.31243328
-2.87%](/price/secret/)
[Smooth Love Potion
$
0.
-1.47%](/price/smooth-love-potion/)
[WINkLink
$
0.
-1.85%](/price/win/)
[Keep Network
$
0.
-0.25%](/price/keep-network/)
[Chromia
$
0.
-0.15%](/price/chromia/)
[NKN
$
0.
-1.52%](/price/nkn/)
[Gitcoin
$
0.99747713
-1.78%](/price/gitcoin/)
[Hashflow
$
0.34353900
-1.81%](/price/hashflow/)
[Bifrost
$
0.
+
3.33%](/price/bfc/)
[Ren
$
0.
-1.74%](/price/ren/)
[Request
$
0.
-2.11%](/price/request/)
[MOBOX
$
0.26999020
-2.05%](/price/mobox/)
[COTI
$
0.
-2.09%](/price/coti/)
[Spell Token
$
0.
-1.62%](/price/spell-token/)
[WazirX
$
0.
-1.71%](/price/wazirx/)
[Galxe
$
1.18
-6.91%](/price/galxe/)
[Bancor
$
0.36221058
-2.81%](/price/bancor/)
[Origin Protocol
$
0.
-3.49%](/price/origin-protocol/)
[Sun Token
$
0.
-2.30%](/price/sun-token/)
[Adventure Gold
$
0.64290640
+
0.90%](/price/agld/)
[ARPA
$
0.
-2.36%](/price/arpa/)
[XYO Network
$
0.
-1.31%](/price/xyo-network/)
[Sweat Economy
$
0.
-0.59%](/price/sweat-economy/)
[Aavegotchi
$
0.92735117
-1.85%](/price/aavegotchi/)
[Voyager Token
$
0.
-4.18%](/price/voyager-token/)
[Boba Network
$
0.
-2.47%](/price/boba-network/)
[Raydium
$
0.20187815
-2.82%](/price/raydium/)
[SuperRare
$
0.
-2.05%](/price/superrare/)
[Maple
$
5.54
+
0.14%](/price/maple/)
[Storj
$
0.29484625
-1.19%](/price/storj/)
[Badger DAO
$
2.12
-2.82%](/price/badger-dao/)
[CEEK VR
$
0.
-2.08%](/price/ceek/)
[Alien Worlds
$
0.
-1.73%](/price/alien-worlds/)
[Index Chain
$
0.
-2.28%](/price/index-chain/)
[GAS
$
2.68
-1.26%](/price/gas/)
[Perpetual Protocol
$
0.50573250
-2.01%](/price/perpetual-protocol/)
[RACA
$
0.
-0.85%](/price/raca/)
[TrueFi
$
0.
-3.28%](/price/truefi/)
[LCX
$
0.
-2.27%](/price/lcx/)
[Moonriver
$
4.82
-2.04%](/price/moonriver/)
[Saitama
$
0.
-0.93%](/price/saitama/)
[Yield Guild Games
$
0.
+
2.09%](/price/yield-guild-games/)
[Reef
$
0.
-1.86%](/price/reef/)
[Serum
$
0.
-2.19%](/price/serum/)
[Ethernity
$
1.73
-4.62%](/price/ethernity/)
[Orchid
$
0.
-1.49%](/price/orchid/)
[Rally
$
0.
-2.49%](/price/rally/)
[Polkastarter
$
0.30922112
-1.83%](/price/polkastarter/)
[Travala.com
$
0.56913777
-6.39%](/price/travalacom/)
[LooksRare
$
0.
-2.67%](/price/looks/)
[Ampleforth Governance
$
2.99
-1.09%](/price/ampleforth-governance/)
[BarnBridge
$
2.92
-3.63%](/price/barnbridge/)
[DIA
$
0.24547946
-1.19%](/price/dia/)
[Keep3rV1
$
54.55
-2.06%](/price/keep3rv1/)
[Virtua
$
0.
-1.48%](/price/virtua/)
[Enzyme
$
17.82
-0.30%](/price/melon/)
[Alpaca Finance
$
0.
-3.42%](/price/alpaca-finance/)
[Velas
$
0.
+
1.90%](/price/velas/)
[Onyxcoin
$
0.
-2.21%](/price/onyxcoin/)
[League of Kingdoms Arena
$
0.22011539
-3.60%](/price/league-of-kingdoms-arena/)
[Alchemix
$
12.77
-1.44%](/price/alchemix/)
[Unifi Protocol DAO
$
3.36
-2.66%](/price/unifi-protocol-dao/)
[Decentral Games
$
0.
-4.10%](/price/decentral-games/)
[MXC
$
0.
+
4.95%](/price/mxc/)
[Star Atlas DAO
$
0.
+
1.66%](/price/star-atlas-dao/)
[CLV
$
0.
-2.03%](/price/clv/)
[Bluzelle
$
0.
-1.83%](/price/blue-zelle/)
[district0x
$
0.
+
12.51%](/price/district0x/)
[0x
$
0.21952928
+
0.64%](/price/0x/)
[Kishu Inu
$
0.
-5.22%](/price/kishu/)
[Star Atlas
$
0.
-0.80%](/price/atlas/)
[Santos FC Fan Token
$
3.22
+
0.03%](/price/santos-fc-fan-token/)
[Harvest Finance
$
24.47
-1.67%](/price/harvest-finance/)
[StaFi
$
0.26612806
-2.40%](/price/stafi/)
[Samoyedcoin
$
0.
-1.27%](/price/samoyedcoin/)
[Bonk
$
0.
-5.65%](/price/bonk/)
[Augur
$
1.55
-0.25%](/price/augur/)
[Rarible
$
1.04
-1.71%](/price/rarible/)
[Green Satoshi Token
$
0.
-0.68%](/price/gst/)
[Tokemak
$
0.56946740
+
0.74%](/price/tokemak/)
[Quantstamp
$
0.
-0.91%](/price/quantstamp/)
[Mirror Protocol
$
0.
+
1.33%](/price/mirror-protocol/)
[SingularDTV
$
0.
0.00%](/price/singulardtv/)
[Quickswap
$
0.
-4.61%](/price/quickswap/)
[FTX Token
$
1.34
-0.92%](/price/ftx-token/)
[Pepe
$
0.
-3.30%](/price/pepe/)
[Threshold
$
0.
-2.27%](/price/threshold/)
[Mines of Dalarnia
$
0.
-2.05%](/price/mines-of-dalarnia/)
[Human
$
0.
-2.24%](/price/human/)
[Pitbull
$
0.
13.82%](/price/pitbull/)
[Tether
$
0.99847027
-0.13%](/price/tether/)
[USD Coin
$
0.99893694
-0.36%](/price/usd-coin/)
[Dai
$
0.99849523
-0.27%](/price/dai/)
![PlayIconNav]()
[Crypto Prices](/data/)
[CoinDesk Market Index](/indices)
[CoinDesk Market Index](/indices/cmi/)
####
Opinion
Fascism on the Blockchain? The Work of Art in the Age of NFTs
===============================================================
The same fascistic tendencies Walter Benjamin saw in the rise of mass media are at play in the NFT "revolution," too, culture critic Jonathan Beller writes.
--------------------------------------------------------------------------------------------------------------------------------------------------------------
By
Jonathan Beller
![AccessTimeIcon]()
Mar 23, 2021 at 4:16 p.m. UTC
Updated
Sep 14, 2021 at 12:31 p.m. UTC
By
Jonathan Beller
![AccessTimeIcon]()
Mar 23, 2021 at 4:16 p.m. UTC
Updated
Sep 14, 2021 at 12:31 p.m. UTC
[share on Facebook]( "share on Facebook")
[share on LinkedIn]( "share on LinkedIn")
[share on Twitter]( "share on Twitter")
![Walter Benjamin wrote "The Work of Art in the Age of Mechanical Reproduction" while the Nazi Party was consolidating power in the 1930s.]():format(jpg)/cloudfront-us-east-1.images.arcpublishing.com/coindesk/N5UK2JWMGNB4PP2PYJC5W2UEKQ.jpg)
Walter Benjamin wrote "The Work of Art in the Age of Mechanical Reproduction" while the Nazi Party was consolidating power in the 1930s.
By
Jonathan Beller
![AccessTimeIcon]()
Mar 23, 2021 at 4:16 p.m. UTC
Updated
Sep 14, 2021 at 12:31 p.m. UTC
[share on Facebook]( "share on Facebook")
[share on LinkedIn]( "share on LinkedIn")
[share on Twitter]( "share on Twitter")
[share on Facebook]( "share on Facebook")
[share on LinkedIn]( "share on LinkedIn")
[share on Twitter]( "share on Twitter")
The Aestheticization of Politics
----------------------------------
When, in 1935, Walter Benjamin undertook his critique of "the work of art in the age of technological reproducibility," this age was in its infancy. He saw in mechanical reproduction a set of possibilities that not only had consequences for art but would change its nature as a medium of social relations.
In a way that can still startle readers, he wrote the emerging capacities of mechanical reproduction, particularly in photography and cinema, might eliminate familiar ways of creating art and "brush aside a number of outmoded concepts, such as creativity and genius, eternal value and mystery - concepts whose uncontrolled (and at present almost uncontrollable) application would lead to a processing of data in the Fascist sense."
Jonathan Beller is professor of Media Studies at Pratt Institute and member of the Economic Space Agency (ECSA) think tank. His forthcoming book, "The World Computer: Derivative Conditions of Racial Capitalism," will be published by Duke University Press in 2021.
Benjamin, who committed suicide while fleeing from the Nazis a few years later, clearly recognized the preservation of cultic values ("genius," "mystery," "authenticity," etc.) in the art of a new media ecology capable of greater democracy served primarily to preserve existing property relations. "The logical result of Fascism is the introduction of aesthetics into political life" and the rise, or rather redeployment, of cult worship through mass entertainment.
Cinema, in particular, was forced to produce celebrities and spectacle rather than be used to connect people and enable them to see and understand one another as creators of value. Under this form of production, benighted individuals served as stand-ins for everyone else, allowing for greater control of people's desires and, therefore, ability to act. Produced by the masses, celebrity is the alienated (and indeed expropriated) agency of the masses.
Today, despite their promises to horizontalize communication and knowledge, both cinema and social media are already taken over by the star and influencer systems. Online identity is composed by collapsing and subsuming other people's attention into one's profile, in what could be seen as a fractalization of the type of fascism Benjamin described.
***See also: Jonathan Beller -
[How We Short Capitalism - And Finance the Revolution](/markets/2020/09/25/how-we-short-capitalism-and-finance-the-revolution/)***
It should give us pause to see the emergent medium that is cryptocurrency undergoing a similar violation. Just as there was a cinema before celebrity culture, and before the medium was adapted to fascistic purposes, there could be another mode of online creation. Is it the historical role of cryptocurrency to take global aspirations for solutions to monetary and social inequality and use this energy to elevate billionaires and artistic geniuses over the masses?
Non-fascist tokens?
---------------------
With the current use of NFTs (non-fungible tokens), blockchain, far from being a system for the radical disintermediation of vested interests, is being "pressed" to redeploy cult values of the capitalist art world and enhance the aura of the unique work of art. It is being used, as Benjamin so presciently understood with respect to the aesthetics of cult value, to "process data in the fascist sense."
*If we are not very careful - and very smart - we will feed the aesthetics of sovereign greed, and botch the historic opportunity to use cryptomedia to create aesthetic forms of community that genuinely, which means also materially and politically, serve the world community*
.
***See also: Elena Giralt -
[Crypto Co-ops and Game Theory: Why the Internet Must Learn to Collaborate to Survive](/markets/2020/09/29/crypto-co-ops-and-game-theory-why-the-internet-must-learn-to-collaborate-to-survive/)***
It is hard here, in a brief comment, to express the degree to which the radical financial imagination is being targeted by a gold rush in NFTs whose very collectibility and value proposition would aim to secure a future not radically different from the economic and cultural conditions of the present or the past, one in which the gods of value - geniuses and creatives - lord their spectacular power over the masses who themselves have created that power.
But the NFT explosion, which threatens to make all art the art of making money, shows the persistence of a financial imagination organized through racial capitalism: artworks become cultic derivatives of fascistic protocols. This fractalization of fascist aesthetics and practices becomes an active, if disavowed or even unconscious (because naturalized), force in platform design and utilization.
This argument, that fascist aesthetics are now on blockchain, will not be well received, I'm sure. But the buzzkill here, that effectively says "meet the new boss, same as the old boss," is not gratuitous. The frenzy around NFTs, the gold rush to get in on the ground floor to individually create and possess attractors that will accumulate future capital, is the exact recipe for a fascism (and for a fractal fascism) that out of the right side of its mouth promises democracy and recognition as it makes its way to the bank to cash in on hierarchy and class difference.
![SingleQuoteLightGreen]()
![SingleQuoteLightGreen]()
Make art though the world shall perish.
![SingleQuoteLightGreen]()
![SingleQuoteLightGreen]()
From Benjamin's perspective, but not only his, this application of a new media form with the potential to transform social relations would be a reactionary application: cryptomedia "pressed" to do the same old things with the same old hierarchies as in past modes of inequality and domination.
What's wrong with cashing in and elevating artists and collectors far above the hordes? A programmable economic medium has, in principle at least, the capacity to democratize finance and indeed to create economic democracy to an extent never before seen. The NFT in and of itself, the ERC 721 or 1135, is not by definition a fascist form.
It is possible, for example, to imagine powerful uses for tokens that serve as unique identifiers for agreements between parties that can in turn be used to collateralize transactions. I offer you X, you offer me Y and based on that agreement we not only build something new but have the means to finance it and share stake with others in our network. Multiply by a billion.
But the sudden perfect fit of the NFT with the cult of genius, and the cult of personality, great artist, celebrity, super athlete and billionaire does not bode well for the democratic and post-capitalist promise of blockchain as the infrastructure of a sustainable world. Playing into habitual aesthetic ideals, this fit with a reactionary tradition threatens to obscure what is really radical about shared stake in aesthetic performance and value creation. Some will shrug, dismiss the "dreamers" and say so what, I don't care if there's blood in my code so long as I'm getting paid. That, of course, is the world we know. There's blood in the banks, in the money and in the code.
But cryptomedia has the potential to do more and better. It has the potential, through disintermediation and remediation, to remake the fabric of society in accord with the call of justice. For this we must also keep art, which has the potential both to create forms of beauty only dreamt of and to transform social relations by creating new aesthetics of relation, from turning into its antithesis - a rationale for the supervaluation of charismatic personalities whose very existence depends upon inequality.
"Fiat ars - pereat mundus [make art though the world shall perish], says Fascism," wrote Benjamin at the end of his essay on the work of art. He understood the belief in "art for art's sake" is not only a fascist anthem, but also a way of aestheticizing politics: creating the pleasures, cultures and ritual structures of legitimation that justify or disavow the underlying dispossessions, forced migrations and genocides vertically integrated into its presumably apolitical values.
[MetaKovan's $69 million Beeple](/markets/2021/03/18/pseudonymous-69m-beeple-nft-buyer-metakovan-reveals-true-identity/)
, about which he said "is going to be a billion-dollar piece, I don't know when," locks up in that valuation a lot of human life in its code even at its current price. This isn't a mere fact, it's a fact mediated by a particular understanding of the role of culture and of finance. At the $1,000-per-year rate paid to much of the working poor in the Global South, that Beeple NFT, with 5,000 days of the artist's work attached to it, becomes valued at about 69,000
*years*
of human time (the work of 69,000 people for one year). That's what is made possible by the aesthetics of inequality.
***See also: Aubrey Strobel -
[The Art of Scarcity](/markets/2021/03/18/the-art-of-scarcity/)***
We see, clearly then, that, in contrast to the way it is being advertised, the NFT currently puts the block and chain back in blockchain. Look again at Beeple's art, at its cold, dead and indifferent, even cheerfully indifferent landscapes and figures. Mankind's, "self-alienation," says Benjamin, "has reached such a degree that it can experience its own destruction as an aesthetic pleasure of the first order. This is the situation of politics which Fascism is rendering aesthetic." I'm not saying Beeple's work is not "of the moment."
Nor am I blaming Beeple for the supervaluation of the NFT in question. But do we really want an aestheticized politics that says, "We, the Beeple?" Or "Hail, Beeple"? Is the result we have been working for in crytpoeconomic design simply the capacity to create fetishized bits of code, capable of capturing 69,000 years of human life, and of delivering the value of those lifetimes to single individuals? Is that the cult crypto was built to serve? Where are the visionaries, coders and artists who will aim for something higher and more just?
NFT does not stand for Non-Fascist Token, but it should. Let's not get fooled again.
---
Learn more about
[Consensus 2024]()
, CoinDesk's longest-running and most influential event that brings together all sides of crypto, blockchain and Web3. Head to
[consensus.coindesk.com]()
to register and buy your pass now.
---
DISCLOSURE
Please note that our
[privacy policy](/privacy/)
,
[terms of use](/terms/)
,
[cookies](/privacy/#cookies)
,
and
[do not sell my personal information](/privacy/#dnsmpi)
has been updated
.
The leader in news and information on cryptocurrency, digital assets and the future of money, CoinDesk is a media outlet that strives for the highest journalistic standards and abides by a
[strict set of editorial policies](/ethics/)
.
CoinDesk is an independent operating subsidiary of
[Digital Currency Group]()
,
which invests in
[cryptocurrencies]()
and blockchain
[startups]()
.
As part of their compensation, certain CoinDesk employees, including editorial employees, may receive exposure to DCG equity in the form of
[stock appreciation rights]()
,
which vest over a multi-year period. CoinDesk journalists are not allowed to purchase stock outright in DCG
.
![Author placeholder image]():format(jpg)/downloads.coindesk.com/arc/failsafe/user/1x1.png)
Jonathan Beller
---
Read more about
[Opinion](/tag/opinion/)
[Philosophy](/tag/philosophy/)
[NFTs](/tag/nfts/)
[![Coindesk Logo]()](/)
About
[About](/about/)
[Masthead](/masthead/)
[Contributors](/contributors/)
[Careers]()
[Company News](/company-news/)
Stay Updated
[Consensus]()
[CoinDesk Studios](/coindeskstudios)
[Newsletters](/newsletters/)
[Follow](/follow/)
Get In Touch
[Contact Us](/contact-us/)
[Advertise](/advertise/)
[Accessibility Help](/accessibility-help/)
[Sitemap](/sitemap/)
The Fine Print
[Ethics Policy](/ethics/)
[Privacy](/privacy/)
[Terms Of Use](/terms/)
[Do Not Sell My Personal Information](/privacy/#dnsmpi)
---
Please note that our
[privacy policy](/privacy/)
,
[terms of use](/terms/)
,
[cookies](/privacy/#cookies)
,
and
[do not sell my personal information](/privacy/#dnsmpi)
has been updated
.
The leader in news and information on cryptocurrency, digital assets and the future of money, CoinDesk is a media outlet that strives for the highest journalistic standards and abides by a
[strict set of editorial policies](/ethics/)
.
CoinDesk is an independent operating subsidiary of
[Digital Currency Group]()
,
which invests in
[cryptocurrencies]()
and blockchain
[startups]()
.
As part of their compensation, certain CoinDesk employees, including editorial employees, may receive exposure to DCG equity in the form of
[stock appreciation rights]()
,
which vest over a multi-year period. CoinDesk journalists are not allowed to purchase stock outright in DCG
.
©️
2023
CoinDesk
English
![MenuUpIcon]()
[Twitter icon]()
[Facebook icon]()
[Linkedin icon]()
[RSS Logo]()
[![TikTokIcon]()]()