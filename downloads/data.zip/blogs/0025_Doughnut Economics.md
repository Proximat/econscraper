DEAL
![]()
![](/assets/backgrounds/Circles-3-aeb86aa49c07b38870d2b51b36cd13503aba5d9de92990cb517469f74cb2723f.svg)
###
The DEAL Community
[![](/assets/link_style_two-aac503990cefac68619a0766af7c5bf0027b47c33f7d14f672193022eb825c09.svg)
Discover the Community](/discover-the-community)
[![](/assets/link_style_two-aac503990cefac68619a0766af7c5bf0027b47c33f7d14f672193022eb825c09.svg)
Members](/members)
[![](/assets/link_style_two-aac503990cefac68619a0766af7c5bf0027b47c33f7d14f672193022eb825c09.svg)
Open Groups & Networks](/groups-and-networks)
[![](/assets/link_style_two-aac503990cefac68619a0766af7c5bf0027b47c33f7d14f672193022eb825c09.svg)
Organisations in action]()
[![](/assets/link_style_two-aac503990cefac68619a0766af7c5bf0027b47c33f7d14f672193022eb825c09.svg)
Principles & Guidelines](/principles-and-guidelines)
[![](/assets/link_style_two-aac503990cefac68619a0766af7c5bf0027b47c33f7d14f672193022eb825c09.svg)
Recent Activity]()
###
News & Events
[![](/assets/link_style_two-aac503990cefac68619a0766af7c5bf0027b47c33f7d14f672193022eb825c09.svg)
News & Updates](/news)
[![](/assets/link_style_two-aac503990cefac68619a0766af7c5bf0027b47c33f7d14f672193022eb825c09.svg)
Events](/events)
###
Tools & Stories
[![](/assets/link_style_two-aac503990cefac68619a0766af7c5bf0027b47c33f7d14f672193022eb825c09.svg)
Discover Tools & Stories](/tools-and-stories)
[![](/assets/link_style_two-aac503990cefac68619a0766af7c5bf0027b47c33f7d14f672193022eb825c09.svg)
Tools]()
[![](/assets/link_style_two-aac503990cefac68619a0766af7c5bf0027b47c33f7d14f672193022eb825c09.svg)
Stories]()
###
Themes
[![](/assets/link_style_two-aac503990cefac68619a0766af7c5bf0027b47c33f7d14f672193022eb825c09.svg)
Explore Themes]()
[![](/assets/link_style_two-aac503990cefac68619a0766af7c5bf0027b47c33f7d14f672193022eb825c09.svg)
Communities & Art]()
[![](/assets/link_style_two-aac503990cefac68619a0766af7c5bf0027b47c33f7d14f672193022eb825c09.svg)
Cities & Regions]()
[![](/assets/link_style_two-aac503990cefac68619a0766af7c5bf0027b47c33f7d14f672193022eb825c09.svg)
Research & Academia]()
[![](/assets/link_style_two-aac503990cefac68619a0766af7c5bf0027b47c33f7d14f672193022eb825c09.svg)
Schools & Education]()
[![](/assets/link_style_two-aac503990cefac68619a0766af7c5bf0027b47c33f7d14f672193022eb825c09.svg)
Business & Enterprise]()
[![](/assets/link_style_two-aac503990cefac68619a0766af7c5bf0027b47c33f7d14f672193022eb825c09.svg)
Government & Policy]()
###
About
[![](/assets/link_style_two-aac503990cefac68619a0766af7c5bf0027b47c33f7d14f672193022eb825c09.svg)
Doughnut Economics](/about-doughnut-economics)
[![](/assets/link_style_two-aac503990cefac68619a0766af7c5bf0027b47c33f7d14f672193022eb825c09.svg)
About DEAL](/about)
[![](/assets/link_style_two-aac503990cefac68619a0766af7c5bf0027b47c33f7d14f672193022eb825c09.svg)
FAQ]()
[![](/assets/link_style_two-aac503990cefac68619a0766af7c5bf0027b47c33f7d14f672193022eb825c09.svg)
Principles & Guidelines](/principles-and-guidelines)
[![](/assets/link_style_two-aac503990cefac68619a0766af7c5bf0027b47c33f7d14f672193022eb825c09.svg)
Wider Movement](/wider-movement)
[![](/assets/link_style_two-aac503990cefac68619a0766af7c5bf0027b47c33f7d14f672193022eb825c09.svg)
Contact Us]()
###
Account
[![](/assets/link_style_two-aac503990cefac68619a0766af7c5bf0027b47c33f7d14f672193022eb825c09.svg)
Sign up](/members/sign_up)
[![](/assets/link_style_two-aac503990cefac68619a0766af7c5bf0027b47c33f7d14f672193022eb825c09.svg)
Log in](/members/sign_in)
* [DEAL Community](# "DEAL Community")
[Discover the Community](/discover-the-community "Discover the Community")
[Members]( "Members")
[Open Groups & Networks]( "Open Groups & Networks")
[Organisations in action]( "Organisations in action")
[Principles & Guidelines](/principles-and-guidelines "Principles & Guidelines")
[Recent Activity]( "Recent Activity")
* [News]( "News")
* [Events]( "Events")
* [Tools & Stories](# "Tools & Stories")
[Discover Tools & Stories](/tools-and-stories "Discover Tools & Stories")
[Tools]( "Tools")
[Stories]( "Stories")
* [Themes](# "Themes")
[Explore Themes]( "Explore Themes")
[Communities & Art]( "Communities & Art")
[Cities & Regions]( "Cities & Regions")
[Research & Academia]( "Research & Academia")
[Schools & Education]( "Schools & Education")
[Business & Enterprise]( "Business & Enterprise")
[Government & Policy]( "Government & Policy")
* [About](# "About")
[Doughnut Economics](/about-doughnut-economics "Doughnut Economics")
[About DEAL](/about "About DEAL")
[FAQ]( "FAQ")
[Principles & Guidelines](/principles-and-guidelines "Principles & Guidelines")
[Wider Movement](/wider-movement "Wider Movement")
[Contact Us]( "Contact Us")
[####
Log in](/members/sign_in)
[Renegade Neighbourhood Economists assemble]()
in the UK
[Doughnut Economics TED Talk]()
by Kate Raworth
Members of
[Donut Brasil]()
Members of
[Climate Action Leeds]()
###
Welcome to DEAL
Turning the ideas of Doughnut Economics into action
=====================================================
[Discover the community](/discover-the-community)
[Join the community](/members/sign_up)
###
Welcome to DEAL
Turning the ideas of Doughnut Economics into action
=====================================================
[Discover the community](/discover-the-community)
[Join the community](/members/sign_up)
Tools
-------
Open access tools that anyone can use to turn Doughnut Economics from a radical idea into transformative action.
From exploratory workshops to activities, lesson plans, methodologies, and more.
[Browse all tools](/tools)
3
#####
[Ecosocial Equilibrium](/tools/224)
Posted by
[[David Lloyd Wright](/members/10082)](/)
[# research](/search?search%5Bq%5D=%23research)
[# teaching-tool](/search?search%5Bq%5D=%23teaching-tool)
[# methodology](/search?search%5Bq%5D=%23methodology)
3
#####
[Integrating Doughnut Econ into business education](/tools/219)
Posted by
[[the DEAL Team]()](/)
[# teaching-tool](/search?search%5Bq%5D=%23teaching-tool)
7
#####
[Translating Biomimicry Daily 4 Dimensions (4Cs)](/tools/217)
Posted by
[[Get Agile](/organisations/39)](/)
[# game](/search?search%5Bq%5D=%23game)
[# activity](/search?search%5Bq%5D=%23activity)
[# workshop](/search?search%5Bq%5D=%23workshop)
[# image](/search?search%5Bq%5D=%23image)
3
#####
[Culture Workshop](/tools/216)
Posted by
[[Peter Hess](/members/21184)](/)
[# workshop](/search?search%5Bq%5D=%23workshop)
15
#####
[Doughnut Economics Seven Ways Zine](/tools/213)
Posted by
[[the DEAL Team]()](/)
[# activity](/search?search%5Bq%5D=%23activity)
18
#####
[Communities: Let's Get Started!](/tools/212)
Posted by
[[the DEAL Team]()](/)
[# explainer](/search?search%5Bq%5D=%23explainer)
[# workshop](/search?search%5Bq%5D=%23workshop)
[# video](/search?search%5Bq%5D=%23video)
[# activity](/search?search%5Bq%5D=%23activity)
27
#####
[Cities & Regions: Let's Get Started](/tools/210)
Posted by
[the DEAL Team](/)
[# explainer](/search?search%5Bq%5D=%23explainer)
5
#####
[Take the Jump](/tools/208)
Posted by
[[Take the Jump]()](/)
8
#####
[Public policies to foster regenerative businesses](/tools/207)
Posted by
[[the DEAL Team]()](/)
[# explainer](/search?search%5Bq%5D=%23explainer)
31
#####
[Doughnut Design for Business - Taster Tool](/tools/206)
Posted by
[[the DEAL Team]()](/)
[# workshop](/search?search%5Bq%5D=%23workshop)
[Browse all tools](/tools)
Stories
---------
Inspiring examples and case studies of Doughnut Economics in action in a broad range of places and contexts.
Dive in and get inspired by existing and on-going projects and initiatives from around the world.
[Browse all stories](/stories)
#####
[Testing the Business Design approach in Brussels](/stories/280)
Posted by
[[Barbara Goffin](/members/15302)](/)
![](/assets/icons/map-marker-alt-66886cec7ac381193171d422adc569b6dd94290e19d0b2b706ebfcd377b3cfb8.svg)
Brussels, Brussels-Capital,...
#####
[Doughnut unrolled for cities during a hackathon](/stories/279)
Posted by
[[Marie-Anne Bernasconi](/members/18168)](/)
![](/assets/icons/map-marker-alt-66886cec7ac381193171d422adc569b6dd94290e19d0b2b706ebfcd377b3cfb8.svg)
Aix-en-Provence, Bouches-du...
2
#####
[Barcelona's Data Portrait: re-rolling the donut](/stories/277)
Posted by
[[Claudio Cattaneo](/members/12324)](/)
![](/assets/icons/map-marker-alt-66886cec7ac381193171d422adc569b6dd94290e19d0b2b706ebfcd377b3cfb8.svg)
Barcelona, Catalonia
#####
[Methodological Insights on BCN data portrait](/stories/276)
Posted by
[[Claudio Cattaneo](/members/12324)](/)
![](/assets/icons/map-marker-alt-66886cec7ac381193171d422adc569b6dd94290e19d0b2b706ebfcd377b3cfb8.svg)
Barcelona, Catalonia
#####
[The Doughnut Journey in Barcelona - workshops](/stories/275)
Posted by
[[Claudio Cattaneo](/members/12324)](/)
![](/assets/icons/map-marker-alt-66886cec7ac381193171d422adc569b6dd94290e19d0b2b706ebfcd377b3cfb8.svg)
Barcelona, Catalonia
#####
[The Doughnut Journey in Barcelona - the process](/stories/274)
Posted by
[[Claudio Cattaneo](/members/12324)](/)
![](/assets/icons/map-marker-alt-66886cec7ac381193171d422adc569b6dd94290e19d0b2b706ebfcd377b3cfb8.svg)
Barcelona
2
#####
[Unrolling the Doughnut: Professionals Community](/stories/272)
Posted by
[[Get Agile](/organisations/39)](/)
![](/assets/icons/map-marker-alt-66886cec7ac381193171d422adc569b6dd94290e19d0b2b706ebfcd377b3cfb8.svg)
Brussels, Brussels-Capital,...
3
#####
[Biomimicry experiments with Doughnut Economics](/stories/269)
Posted by
[[Get Agile](/organisations/39)](/)
![](/assets/icons/map-marker-alt-66886cec7ac381193171d422adc569b6dd94290e19d0b2b706ebfcd377b3cfb8.svg)
Online
2
#####
[Our complicated relationship with products](/stories/266)
Posted by
[[West Cork Doughnut Economy Network](/groups-and-networks/28)](/)
![](/assets/icons/map-marker-alt-66886cec7ac381193171d422adc569b6dd94290e19d0b2b706ebfcd377b3cfb8.svg)
49 North Street, Skibbereen...
4
#####
[Exploring the deep design of business through play](/stories/264)
Posted by
[[Peter Lefort](/members/17036)](/)
![](/assets/icons/map-marker-alt-66886cec7ac381193171d422adc569b6dd94290e19d0b2b706ebfcd377b3cfb8.svg)
Cornwall, England, United K...
[Browse all stories](/stories)
Upcoming events
-----------------
Upcoming Doughnut Economics events - both online and in-person - by and for the DEAL Community.
[Browse all events](/events)
![](/assets/icons/user-followers-7c99ec891977a67d9397901f4cd8daa16666fe2477b218cfa3c59a8fca8f2c6b.svg)
2
2023-08-27T16:00:00Z
#####
[Whole Earth Economics (WEE) Project](/events/302)
Posted by
[[Sanford Hinden](/members/4731)](/)
![](/assets/icons/map-marker-alt-66886cec7ac381193171d422adc569b6dd94290e19d0b2b706ebfcd377b3cfb8.svg)
Online
![](/assets/icons/user-followers-7c99ec891977a67d9397901f4cd8daa16666fe2477b218cfa3c59a8fca8f2c6b.svg)
1
2023-10-06T14:00:00Z
#####
[DARE 1.0 - An Event for Female Entrepreneurs](/events/296)
Posted by
[[Amber Wan](/members/21244)](/)
![](/assets/icons/map-marker-alt-66886cec7ac381193171d422adc569b6dd94290e19d0b2b706ebfcd377b3cfb8.svg)
Ibiza, Santa Eularia des Ri...
[Browse all events](/events)
News & Updates
----------------
The most important Doughnut Economics news, updates and highlights, curated by the DEAL Team.
[Browse all news & updates](/news)
1
#####
[DEAL's 2-Part Doughnut Design for Business Trainings (6 & 26 July)](/news/62)
3
#####
[DEAL's business tool available in French, German, Portuguese & Spanish](/news/61)
#####
[Study says global North owes $170 trillion for excessive CO2 emissions](/news/60)
13
#####
[The Doughnut Design for Business tool launches!](/news/59)
6
#####
[We're hiring! Could you be DEAL's Schools & Education Lead? [Closed]](/news/58)
6
#####
[DEAL Community Platform 2.0 Update](/news/57)
10
#####
[We're hiring! Could you be DEAL's Communications Lead? [Closed]](/news/56)
3
#####
[Introducing open groups and networks](/news/55)
1
#####
[We're hiring! Could you be DEAL's Operations Lead? [Closed]](/news/54)
3
#####
[Doughnut Economics in the deep design of business](/news/50)
[Browse all news & updates](/news)
The DEAL Community
--------------------
#####
Show me:
Members
Events
Stories
Networks
Cities & Regions
[Discover the community](/discover-the-community)
![](/assets/backgrounds/Circles-2-8a7b79cc338b2a96b9ac20c95506c9257407f95a7b9ece2ac69ef0e136e9d49c.svg)
Join the DEAL Community!
--------------------------
Get inspired, connect with others and become part of the movement. No matter how big or small your contribution is, you're welcome to join!
[Discover the community](/discover-the-community)
[Join the community](/members/sign_up)
[![](/assets/socials/Twitter-3890a260889fed284a6ffd40bf8654f2b19bec5681403b42d30ea4fde63f9ece.svg)]()
[![](/assets/socials/Instagram-7d0ef0bb94039689f2f3fe41407085149b5c77f6ff4a48d1c00df91b6fd5a2dc.svg)]()
[![](/assets/socials/Facebook-378112248f5ae7c45e8a6ad97b530af974b2f5f773d38e44dfadd6f69cf756c7.svg)]()
[![](/assets/socials/YouTube-c7436452c3c2e1a4d35f45b20abf83277fc645d72f189407a7efb7149dcc84a7.svg)]()
[![](/assets/socials/Linkedin-79141ee753a7101e7ac814f5e48d60f1cd8a9758c60373ffaeb947c4b3cb8479.svg)]()
---
DEAL Community
* [Discover the Community](/discover-the-community)
* [Tools & Stories](/tools-and-stories)
* [Events]()
* [Members]()
* [Groups & Networks]()
* [Organisations in action]()
About
* [Doughnut Economics](/about-doughnut-economics)
* [About DEAL](/about)
* [News & Updates]()
* [FAQ](/faq)
* [Contact us](/contact)
More Info
* [Principles & Guidelines](/principles-and-guidelines)
* [Wider Movement](/wider-movement)
* [Funding & Support](/funding-support)
* [Press & Media](/press)
* [Platform Development Hub](/platform-development-hub)
The DEAL Newsletter
Subscribe to the DEAL Newsletter and receive key updates every month!
![](/assets/next-3e281bc3745043f02fec0165f5ee05db43515c74795cb8d9c6eda5e7936fd66d.svg)
![](/assets/arrow-black-a7d95b2e03897a40b794a2c0d3aac150e43a71f11b175c5eff55b256d9e1bf61.png)
[![](/assets/socials/Twitter-3890a260889fed284a6ffd40bf8654f2b19bec5681403b42d30ea4fde63f9ece.svg)]()
[![](/assets/socials/Instagram-7d0ef0bb94039689f2f3fe41407085149b5c77f6ff4a48d1c00df91b6fd5a2dc.svg)]()
[![](/assets/socials/Facebook-378112248f5ae7c45e8a6ad97b530af974b2f5f773d38e44dfadd6f69cf756c7.svg)]()
[![](/assets/socials/YouTube-c7436452c3c2e1a4d35f45b20abf83277fc645d72f189407a7efb7149dcc84a7.svg)]()
[![](/assets/socials/Linkedin-79141ee753a7101e7ac814f5e48d60f1cd8a9758c60373ffaeb947c4b3cb8479.svg)]()
[Terms of Use](/terms-of-use)
|
[Privacy Notice](/privacy-notice)
- ©️ Doughnut Economics Action Lab (2023)
[Terms of Use](/terms-of-use)
|
[Privacy Notice](/privacy-notice)
©️ Doughnut Economics Action Lab (2023)
#####
Loading...
Loading...